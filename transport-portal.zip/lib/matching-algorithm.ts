// Matching algorithm for connecting passenger intents with driver availability

interface PassengerIntent {
  id: string
  passenger_id: string
  from_location: string
  to_location: string
  from_latitude?: number
  from_longitude?: number
  to_latitude?: number
  to_longitude?: number
  preferred_departure_time: string
  flexible_time_minutes: number
  max_budget: number
  passenger_count: number
  special_requirements?: string
  status: string
}

interface DriverAvailability {
  id: string
  driver_id: string
  from_location: string
  to_location: string
  from_latitude?: number
  from_longitude?: number
  to_latitude?: number
  to_longitude?: number
  available_from: string
  available_until: string
  min_price: number
  max_price: number
  available_seats: number
  route_flexibility: string
  status: string
}

interface MatchResult {
  passenger_intent_id: string
  driver_availability_id: string
  match_score: number
  suggested_price: number
  pickup_time: string
  compatibility_factors: {
    location_score: number
    time_score: number
    price_score: number
    capacity_score: number
    flexibility_score: number
  }
}

// Calculate distance between two points using Haversine formula (simplified)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371 // Earth's radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

// Calculate location compatibility score
function calculateLocationScore(intent: PassengerIntent, availability: DriverAvailability): number {
  // If we have coordinates, use distance calculation
  if (
    intent.from_latitude &&
    intent.from_longitude &&
    availability.from_latitude &&
    availability.from_longitude &&
    intent.to_latitude &&
    intent.to_longitude &&
    availability.to_latitude &&
    availability.to_longitude
  ) {
    const fromDistance = calculateDistance(
      intent.from_latitude,
      intent.from_longitude,
      availability.from_latitude,
      availability.from_longitude,
    )

    const toDistance = calculateDistance(
      intent.to_latitude,
      intent.to_longitude,
      availability.to_latitude,
      availability.to_longitude,
    )

    // Score based on proximity (closer = higher score)
    const maxAcceptableDistance = 10 // 10km max deviation
    const fromScore = Math.max(0, (maxAcceptableDistance - fromDistance) / maxAcceptableDistance)
    const toScore = Math.max(0, (maxAcceptableDistance - toDistance) / maxAcceptableDistance)

    return (fromScore + toScore) / 2
  }

  // Fallback to string matching if no coordinates
  const fromMatch =
    intent.from_location.toLowerCase().includes(availability.from_location.toLowerCase()) ||
    availability.from_location.toLowerCase().includes(intent.from_location.toLowerCase())
  const toMatch =
    intent.to_location.toLowerCase().includes(availability.to_location.toLowerCase()) ||
    availability.to_location.toLowerCase().includes(intent.to_location.toLowerCase())

  if (fromMatch && toMatch) return 1.0
  if (fromMatch || toMatch) return 0.5
  return 0.0
}

// Calculate time compatibility score
function calculateTimeScore(intent: PassengerIntent, availability: DriverAvailability): number {
  const intentTime = new Date(intent.preferred_departure_time)
  const availableFrom = new Date(availability.available_from)
  const availableUntil = new Date(availability.available_until)

  // Check if intent time falls within availability window
  if (intentTime >= availableFrom && intentTime <= availableUntil) {
    return 1.0
  }

  // Check if intent time with flexibility overlaps with availability
  const flexibilityMs = intent.flexible_time_minutes * 60 * 1000
  const intentEarliest = new Date(intentTime.getTime() - flexibilityMs)
  const intentLatest = new Date(intentTime.getTime() + flexibilityMs)

  // Check for any overlap
  if (intentLatest >= availableFrom && intentEarliest <= availableUntil) {
    // Calculate overlap percentage
    const overlapStart = new Date(Math.max(intentEarliest.getTime(), availableFrom.getTime()))
    const overlapEnd = new Date(Math.min(intentLatest.getTime(), availableUntil.getTime()))
    const overlapDuration = overlapEnd.getTime() - overlapStart.getTime()
    const totalFlexibilityDuration = flexibilityMs * 2

    return Math.min(1.0, overlapDuration / totalFlexibilityDuration)
  }

  return 0.0
}

// Calculate price compatibility score
function calculatePriceScore(intent: PassengerIntent, availability: DriverAvailability): number {
  const passengerBudget = intent.max_budget
  const driverMinPrice = availability.min_price
  const driverMaxPrice = availability.max_price

  // Perfect match if passenger budget falls within driver's price range
  if (passengerBudget >= driverMinPrice && passengerBudget <= driverMaxPrice) {
    return 1.0
  }

  // Partial match if there's some overlap potential
  if (passengerBudget >= driverMinPrice * 0.8) {
    return 0.7
  }

  if (passengerBudget >= driverMinPrice * 0.6) {
    return 0.4
  }

  return 0.0
}

// Calculate capacity compatibility score
function calculateCapacityScore(intent: PassengerIntent, availability: DriverAvailability): number {
  if (intent.passenger_count <= availability.available_seats) {
    return 1.0
  }
  return 0.0
}

// Calculate flexibility score based on driver's route flexibility
function calculateFlexibilityScore(intent: PassengerIntent, availability: DriverAvailability): number {
  switch (availability.route_flexibility) {
    case "very_flexible":
      return 1.0
    case "flexible":
      return 0.7
    case "exact":
      return 0.4
    default:
      return 0.4
  }
}

// Main matching function
export function calculateMatch(intent: PassengerIntent, availability: DriverAvailability): MatchResult | null {
  // Basic compatibility checks
  const capacityScore = calculateCapacityScore(intent, availability)
  if (capacityScore === 0) {
    return null // Can't fit passengers
  }

  const locationScore = calculateLocationScore(intent, availability)
  if (locationScore === 0) {
    return null // No location compatibility
  }

  const timeScore = calculateTimeScore(intent, availability)
  if (timeScore === 0) {
    return null // No time compatibility
  }

  const priceScore = calculatePriceScore(intent, availability)
  if (priceScore === 0) {
    return null // No price compatibility
  }

  const flexibilityScore = calculateFlexibilityScore(intent, availability)

  // Calculate weighted overall score
  const weights = {
    location: 0.3,
    time: 0.25,
    price: 0.25,
    capacity: 0.1,
    flexibility: 0.1,
  }

  const overallScore =
    locationScore * weights.location +
    timeScore * weights.time +
    priceScore * weights.price +
    capacityScore * weights.capacity +
    flexibilityScore * weights.flexibility

  // Calculate suggested price (midpoint between passenger budget and driver's range)
  const suggestedPrice = Math.min(
    intent.max_budget,
    (availability.min_price + Math.min(availability.max_price, intent.max_budget)) / 2,
  )

  // Calculate optimal pickup time
  const intentTime = new Date(intent.preferred_departure_time)
  const availableFrom = new Date(availability.available_from)
  const availableUntil = new Date(availability.available_until)

  let pickupTime = intentTime
  if (intentTime < availableFrom) {
    pickupTime = availableFrom
  } else if (intentTime > availableUntil) {
    pickupTime = availableUntil
  }

  return {
    passenger_intent_id: intent.id,
    driver_availability_id: availability.id,
    match_score: Math.round(overallScore * 100) / 100,
    suggested_price: Math.round(suggestedPrice * 100) / 100,
    pickup_time: pickupTime.toISOString(),
    compatibility_factors: {
      location_score: Math.round(locationScore * 100) / 100,
      time_score: Math.round(timeScore * 100) / 100,
      price_score: Math.round(priceScore * 100) / 100,
      capacity_score: Math.round(capacityScore * 100) / 100,
      flexibility_score: Math.round(flexibilityScore * 100) / 100,
    },
  }
}

// Find all matches for a passenger intent
export function findMatchesForIntent(intent: PassengerIntent, availabilities: DriverAvailability[]): MatchResult[] {
  const matches: MatchResult[] = []

  for (const availability of availabilities) {
    // Skip if same user or inactive
    if (availability.driver_id === intent.passenger_id || availability.status !== "active") {
      continue
    }

    const match = calculateMatch(intent, availability)
    if (match && match.match_score >= 0.3) {
      // Minimum 30% compatibility
      matches.push(match)
    }
  }

  // Sort by match score (highest first)
  return matches.sort((a, b) => b.match_score - a.match_score)
}

// Find all matches for a driver availability
export function findMatchesForAvailability(
  availability: DriverAvailability,
  intents: PassengerIntent[],
): MatchResult[] {
  const matches: MatchResult[] = []

  for (const intent of intents) {
    // Skip if same user or inactive
    if (intent.passenger_id === availability.driver_id || intent.status !== "active") {
      continue
    }

    const match = calculateMatch(intent, availability)
    if (match && match.match_score >= 0.3) {
      // Minimum 30% compatibility
      matches.push(match)
    }
  }

  // Sort by match score (highest first)
  return matches.sort((a, b) => b.match_score - a.match_score)
}
