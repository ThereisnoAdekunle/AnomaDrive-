-- Create payment_methods table for storing user payment information
CREATE TABLE IF NOT EXISTS public.payment_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('card', 'bank_account', 'digital_wallet')),
  provider TEXT NOT NULL, -- stripe, paypal, etc.
  external_id TEXT NOT NULL, -- payment method ID from provider
  last_four TEXT,
  brand TEXT, -- visa, mastercard, etc.
  is_default BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create transactions table for tracking all payments
CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES public.intent_matches(id) ON DELETE CASCADE,
  passenger_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  platform_fee DECIMAL(10, 2) NOT NULL DEFAULT 0,
  driver_earnings DECIMAL(10, 2) NOT NULL,
  payment_method_id UUID REFERENCES public.payment_methods(id),
  external_payment_id TEXT, -- payment ID from payment provider
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'authorized', 'captured', 'failed', 'refunded', 'disputed')),
  payment_intent_id TEXT, -- for escrow functionality
  authorized_at TIMESTAMP WITH TIME ZONE,
  captured_at TIMESTAMP WITH TIME ZONE,
  failed_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create ride_sessions table for tracking ride progress and payment triggers
CREATE TABLE IF NOT EXISTS public.ride_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id UUID NOT NULL REFERENCES public.intent_matches(id) ON DELETE CASCADE,
  transaction_id UUID REFERENCES public.transactions(id),
  status TEXT NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'started', 'in_progress', 'completed', 'cancelled')),
  pickup_location TEXT,
  dropoff_location TEXT,
  actual_pickup_time TIMESTAMP WITH TIME ZONE,
  actual_dropoff_time TIMESTAMP WITH TIME ZONE,
  distance_km DECIMAL(8, 2),
  duration_minutes INTEGER,
  passenger_confirmed_pickup BOOLEAN DEFAULT FALSE,
  passenger_confirmed_dropoff BOOLEAN DEFAULT FALSE,
  driver_confirmed_pickup BOOLEAN DEFAULT FALSE,
  driver_confirmed_dropoff BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create payment_disputes table for handling payment issues
CREATE TABLE IF NOT EXISTS public.payment_disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  initiated_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  dispute_type TEXT NOT NULL CHECK (dispute_type IN ('service_not_provided', 'overcharge', 'quality_issue', 'other')),
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'closed')),
  resolution TEXT,
  resolved_by UUID REFERENCES public.profiles(id),
  resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ride_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_disputes ENABLE ROW LEVEL SECURITY;

-- Create policies for payment_methods
CREATE POLICY "payment_methods_select_own" ON public.payment_methods 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "payment_methods_insert_own" ON public.payment_methods 
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "payment_methods_update_own" ON public.payment_methods 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "payment_methods_delete_own" ON public.payment_methods 
  FOR DELETE USING (auth.uid() = user_id);

-- Create policies for transactions (users can see transactions they're involved in)
CREATE POLICY "transactions_select_involved" ON public.transactions 
  FOR SELECT USING (auth.uid() = passenger_id OR auth.uid() = driver_id);

-- Create policies for ride_sessions (users can see sessions they're involved in)
CREATE POLICY "ride_sessions_select_involved" ON public.ride_sessions 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.intent_matches im
      JOIN public.passenger_intents pi ON im.passenger_intent_id = pi.id
      JOIN public.driver_availability da ON im.driver_availability_id = da.id
      WHERE im.id = match_id AND (pi.passenger_id = auth.uid() OR da.driver_id = auth.uid())
    )
  );

CREATE POLICY "ride_sessions_update_involved" ON public.ride_sessions 
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.intent_matches im
      JOIN public.passenger_intents pi ON im.passenger_intent_id = pi.id
      JOIN public.driver_availability da ON im.driver_availability_id = da.id
      WHERE im.id = match_id AND (pi.passenger_id = auth.uid() OR da.driver_id = auth.uid())
    )
  );

-- Create policies for payment_disputes
CREATE POLICY "payment_disputes_select_involved" ON public.payment_disputes 
  FOR SELECT USING (
    auth.uid() = initiated_by OR 
    EXISTS (
      SELECT 1 FROM public.transactions t 
      WHERE t.id = transaction_id AND (t.passenger_id = auth.uid() OR t.driver_id = auth.uid())
    )
  );

CREATE POLICY "payment_disputes_insert_involved" ON public.payment_disputes 
  FOR INSERT WITH CHECK (
    auth.uid() = initiated_by AND
    EXISTS (
      SELECT 1 FROM public.transactions t 
      WHERE t.id = transaction_id AND (t.passenger_id = auth.uid() OR t.driver_id = auth.uid())
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_methods_user_id ON public.payment_methods(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_match_id ON public.transactions(match_id);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON public.transactions(status);
CREATE INDEX IF NOT EXISTS idx_ride_sessions_match_id ON public.ride_sessions(match_id);
CREATE INDEX IF NOT EXISTS idx_ride_sessions_status ON public.ride_sessions(status);
