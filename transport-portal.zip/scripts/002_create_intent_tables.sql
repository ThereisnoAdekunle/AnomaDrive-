-- Create passenger_intents table
CREATE TABLE IF NOT EXISTS public.passenger_intents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  passenger_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  from_location TEXT NOT NULL,
  to_location TEXT NOT NULL,
  from_latitude DECIMAL(10, 8),
  from_longitude DECIMAL(11, 8),
  to_latitude DECIMAL(10, 8),
  to_longitude DECIMAL(11, 8),
  preferred_departure_time TIMESTAMP WITH TIME ZONE NOT NULL,
  flexible_time_minutes INTEGER DEFAULT 30,
  max_budget DECIMAL(10, 2) NOT NULL,
  passenger_count INTEGER NOT NULL DEFAULT 1,
  special_requirements TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'matched', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create driver_availability table
CREATE TABLE IF NOT EXISTS public.driver_availability (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  from_location TEXT NOT NULL,
  to_location TEXT NOT NULL,
  from_latitude DECIMAL(10, 8),
  from_longitude DECIMAL(11, 8),
  to_latitude DECIMAL(10, 8),
  to_longitude DECIMAL(11, 8),
  available_from TIMESTAMP WITH TIME ZONE NOT NULL,
  available_until TIMESTAMP WITH TIME ZONE NOT NULL,
  min_price DECIMAL(10, 2) NOT NULL,
  max_price DECIMAL(10, 2) NOT NULL,
  available_seats INTEGER NOT NULL,
  route_flexibility TEXT DEFAULT 'exact' CHECK (route_flexibility IN ('exact', 'flexible', 'very_flexible')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'matched', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create matches table for tracking intent matches
CREATE TABLE IF NOT EXISTS public.intent_matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  passenger_intent_id UUID NOT NULL REFERENCES public.passenger_intents(id) ON DELETE CASCADE,
  driver_availability_id UUID NOT NULL REFERENCES public.driver_availability(id) ON DELETE CASCADE,
  match_score DECIMAL(5, 2) NOT NULL,
  agreed_price DECIMAL(10, 2),
  pickup_time TIMESTAMP WITH TIME ZONE,
  pickup_location TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.passenger_intents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.intent_matches ENABLE ROW LEVEL SECURITY;

-- Create policies for passenger_intents
CREATE POLICY "passenger_intents_select_own" ON public.passenger_intents 
  FOR SELECT USING (auth.uid() = passenger_id);

CREATE POLICY "passenger_intents_insert_own" ON public.passenger_intents 
  FOR INSERT WITH CHECK (auth.uid() = passenger_id);

CREATE POLICY "passenger_intents_update_own" ON public.passenger_intents 
  FOR UPDATE USING (auth.uid() = passenger_id);

CREATE POLICY "passenger_intents_delete_own" ON public.passenger_intents 
  FOR DELETE USING (auth.uid() = passenger_id);

-- Create policies for driver_availability
CREATE POLICY "driver_availability_select_own" ON public.driver_availability 
  FOR SELECT USING (auth.uid() = driver_id);

CREATE POLICY "driver_availability_insert_own" ON public.driver_availability 
  FOR INSERT WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "driver_availability_update_own" ON public.driver_availability 
  FOR UPDATE USING (auth.uid() = driver_id);

CREATE POLICY "driver_availability_delete_own" ON public.driver_availability 
  FOR DELETE USING (auth.uid() = driver_id);

-- Create policies for intent_matches (users can see matches involving their intents)
CREATE POLICY "intent_matches_select_passenger" ON public.intent_matches 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.passenger_intents 
      WHERE id = passenger_intent_id AND passenger_id = auth.uid()
    )
  );

CREATE POLICY "intent_matches_select_driver" ON public.intent_matches 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.driver_availability 
      WHERE id = driver_availability_id AND driver_id = auth.uid()
    )
  );

CREATE POLICY "intent_matches_update_passenger" ON public.intent_matches 
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.passenger_intents 
      WHERE id = passenger_intent_id AND passenger_id = auth.uid()
    )
  );

CREATE POLICY "intent_matches_update_driver" ON public.intent_matches 
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM public.driver_availability 
      WHERE id = driver_availability_id AND driver_id = auth.uid()
    )
  );

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_passenger_intents_status ON public.passenger_intents(status);
CREATE INDEX IF NOT EXISTS idx_passenger_intents_departure_time ON public.passenger_intents(preferred_departure_time);
CREATE INDEX IF NOT EXISTS idx_driver_availability_status ON public.driver_availability(status);
CREATE INDEX IF NOT EXISTS idx_driver_availability_time ON public.driver_availability(available_from, available_until);
CREATE INDEX IF NOT EXISTS idx_intent_matches_status ON public.intent_matches(status);
