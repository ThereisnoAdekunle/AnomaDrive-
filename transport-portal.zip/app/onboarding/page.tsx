import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import OnboardingForm from "@/components/onboarding-form"

export default async function OnboardingPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user already has a complete profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (profile && profile.full_name) {
    // User already onboarded, redirect to dashboard
    if (profile.user_type === "driver") {
      redirect("/dashboard/driver")
    } else {
      redirect("/dashboard/passenger")
    }
  }

  return <OnboardingForm user={user} />
}
