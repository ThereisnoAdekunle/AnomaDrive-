import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import CreateAvailabilityForm from "@/components/create-availability-form"

export default async function CreateAvailabilityPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and driver profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/onboarding")
  }

  if (profile.user_type !== "driver") {
    redirect("/dashboard/passenger")
  }

  // Check driver verification
  const { data: driverProfile } = await supabase.from("driver_profiles").select("*").eq("id", user.id).single()

  if (!driverProfile || driverProfile.verification_status !== "approved") {
    redirect("/dashboard/driver")
  }

  return <CreateAvailabilityForm user={user} profile={profile} driverProfile={driverProfile} />
}
