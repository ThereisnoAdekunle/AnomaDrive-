import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import PaymentFlow from "@/components/payment-flow"

interface PaymentPageProps {
  params: Promise<{ matchId: string }>
}

export default async function PaymentPage({ params }: PaymentPageProps) {
  const { matchId } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get match details
  const { data: match } = await supabase
    .from("intent_matches")
    .select(`
      *,
      passenger_intents!inner(*),
      driver_availability!inner(*)
    `)
    .eq("id", matchId)
    .single()

  if (!match) {
    redirect("/matches")
  }

  // Verify user is the passenger
  if (user.id !== match.passenger_intents.passenger_id) {
    redirect("/matches")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Get driver profile
  const { data: driverProfile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", match.driver_availability.driver_id)
    .single()

  // Get existing transaction if any
  const { data: existingTransaction } = await supabase.from("transactions").select("*").eq("match_id", matchId).single()

  return (
    <PaymentFlow
      user={user}
      profile={profile}
      match={match}
      driverProfile={driverProfile}
      existingTransaction={existingTransaction}
    />
  )
}
