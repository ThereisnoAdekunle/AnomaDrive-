import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

interface RouteParams {
  params: Promise<{ driverId: string }>
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { driverId } = await params
    const supabase = await createClient()

    const url = new URL(request.url)
    const page = Number.parseInt(url.searchParams.get("page") || "1")
    const limit = Number.parseInt(url.searchParams.get("limit") || "10")
    const offset = (page - 1) * limit

    // Get driver ratings summary
    const { data: summary } = await supabase
      .from("driver_ratings_summary")
      .select("*")
      .eq("driver_id", driverId)
      .single()

    // Get reviews with reviewer information
    const { data: reviews, error } = await supabase
      .from("reviews")
      .select(`
        *,
        profiles!reviews_reviewer_id_fkey(full_name),
        review_categories(category_name, rating)
      `)
      .eq("reviewee_id", driverId)
      .eq("reviewer_type", "passenger")
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1)

    if (error) {
      throw error
    }

    // Get total count for pagination
    const { count } = await supabase
      .from("reviews")
      .select("*", { count: "exact", head: true })
      .eq("reviewee_id", driverId)
      .eq("reviewer_type", "passenger")

    return NextResponse.json({
      summary: summary || {
        driver_id: driverId,
        total_reviews: 0,
        average_rating: 0,
        five_star_count: 0,
        four_star_count: 0,
        three_star_count: 0,
        two_star_count: 0,
        one_star_count: 0,
      },
      reviews: reviews || [],
      pagination: {
        page,
        limit,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching driver reviews:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
