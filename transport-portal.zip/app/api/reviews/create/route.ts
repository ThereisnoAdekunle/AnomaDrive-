import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { ride_session_id, rating, title, comment, categories, is_anonymous } = await request.json()

    // Validate rating
    if (!rating || rating < 1 || rating > 5) {
      return NextResponse.json({ error: "Rating must be between 1 and 5" }, { status: 400 })
    }

    // Get ride session and verify user can review
    const { data: rideSession } = await supabase
      .from("ride_sessions")
      .select(`
        *,
        intent_matches!inner(
          passenger_intents!inner(passenger_id),
          driver_availability!inner(driver_id)
        )
      `)
      .eq("id", ride_session_id)
      .eq("status", "completed")
      .single()

    if (!rideSession) {
      return NextResponse.json({ error: "Ride session not found or not completed" }, { status: 404 })
    }

    const passengerMatch = rideSession.intent_matches
    const isPassenger = user.id === passengerMatch.passenger_intents.passenger_id
    const isDriver = user.id === passengerMatch.driver_availability.driver_id

    if (!isPassenger && !isDriver) {
      return NextResponse.json({ error: "You can only review rides you participated in" }, { status: 403 })
    }

    // Determine reviewer and reviewee
    const reviewerId = user.id
    const revieweeId = isPassenger
      ? passengerMatch.driver_availability.driver_id
      : passengerMatch.passenger_intents.passenger_id
    const reviewerType = isPassenger ? "passenger" : "driver"

    // Check if review already exists
    const { data: existingReview } = await supabase
      .from("reviews")
      .select("id")
      .eq("ride_session_id", ride_session_id)
      .eq("reviewer_id", reviewerId)
      .single()

    if (existingReview) {
      return NextResponse.json({ error: "You have already reviewed this ride" }, { status: 400 })
    }

    // Create review
    const { data: review, error: reviewError } = await supabase
      .from("reviews")
      .insert({
        ride_session_id,
        reviewer_id: reviewerId,
        reviewee_id: revieweeId,
        reviewer_type: reviewerType,
        rating,
        title,
        comment,
        is_anonymous: is_anonymous || false,
      })
      .select()
      .single()

    if (reviewError) {
      throw reviewError
    }

    // Create category ratings if provided
    if (categories && Array.isArray(categories)) {
      const categoryInserts = categories.map((cat) => ({
        review_id: review.id,
        category_name: cat.name,
        rating: cat.rating,
      }))

      await supabase.from("review_categories").insert(categoryInserts)
    }

    return NextResponse.json({ review })
  } catch (error) {
    console.error("Error creating review:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
