import { createClient } from "@/lib/supabase/server"
import { paymentService } from "@/lib/payment-service"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { match_id } = await request.json()

    // Get match details and verify user is the passenger
    const { data: match } = await supabase
      .from("intent_matches")
      .select(`
        *,
        passenger_intents!inner(passenger_id),
        driver_availability!inner(driver_id)
      `)
      .eq("id", match_id)
      .eq("status", "accepted")
      .single()

    if (!match) {
      return NextResponse.json({ error: "Match not found or not accepted" }, { status: 404 })
    }

    if (user.id !== match.passenger_intents.passenger_id) {
      return NextResponse.json({ error: "Only the passenger can initiate payment" }, { status: 403 })
    }

    // Check if payment already exists
    const { data: existingTransaction } = await supabase
      .from("transactions")
      .select("*")
      .eq("match_id", match_id)
      .single()

    if (existingTransaction) {
      return NextResponse.json({ error: "Payment already exists for this match" }, { status: 400 })
    }

    const amount = match.agreed_price || match.suggested_price

    // Validate payment details
    const validation = paymentService.validatePaymentDetails(amount)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.errors.join(", ") }, { status: 400 })
    }

    // Create payment intent for escrow
    const paymentIntent = await paymentService.createEscrowPayment(amount)

    // Calculate fees and earnings
    const platformFee = paymentService.calculatePlatformFee(amount)
    const driverEarnings = paymentService.calculateDriverEarnings(amount)

    // Create transaction record
    const { data: transaction, error } = await supabase
      .from("transactions")
      .insert({
        match_id,
        passenger_id: match.passenger_intents.passenger_id,
        driver_id: match.driver_availability.driver_id,
        amount,
        platform_fee: platformFee,
        driver_earnings: driverEarnings,
        payment_intent_id: paymentIntent.id,
        status: "pending",
      })
      .select()
      .single()

    if (error) {
      throw error
    }

    return NextResponse.json({
      transaction,
      payment_intent: paymentIntent,
    })
  } catch (error) {
    console.error("Error creating payment intent:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
