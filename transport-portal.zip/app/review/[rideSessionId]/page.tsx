import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ReviewForm from "@/components/review-form"

interface ReviewPageProps {
  params: Promise<{ rideSessionId: string }>
}

export default async function ReviewPage({ params }: ReviewPageProps) {
  const { rideSessionId } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get ride session details
  const { data: rideSession } = await supabase
    .from("ride_sessions")
    .select(`
      *,
      intent_matches!inner(
        *,
        passenger_intents!inner(*),
        driver_availability!inner(*)
      )
    `)
    .eq("id", rideSessionId)
    .eq("status", "completed")
    .single()

  if (!rideSession) {
    redirect("/matches")
  }

  // Verify user participated in this ride
  const passengerMatch = rideSession.intent_matches
  const isPassenger = user.id === passengerMatch.passenger_intents.passenger_id
  const isDriver = user.id === passengerMatch.driver_availability.driver_id

  if (!isPassenger && !isDriver) {
    redirect("/matches")
  }

  // Get profiles
  const { data: passengerProfile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", passengerMatch.passenger_intents.passenger_id)
    .single()

  const { data: driverProfile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", passengerMatch.driver_availability.driver_id)
    .single()

  // Check if review already exists
  const { data: existingReview } = await supabase
    .from("reviews")
    .select("*")
    .eq("ride_session_id", rideSessionId)
    .eq("reviewer_id", user.id)
    .single()

  return (
    <ReviewForm
      user={user}
      rideSession={rideSession}
      passengerProfile={passengerProfile}
      driverProfile={driverProfile}
      isPassenger={isPassenger}
      existingReview={existingReview}
    />
  )
}
