"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { MapPin, Clock, DollarSign, Users, ArrowLeft, Car } from "lucide-react"
import Link from "next/link"

interface CreateIntentFormProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    user_type: string
  }
}

export default function CreateIntentForm({ user, profile }: CreateIntentFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // Form data
  const [fromLocation, setFromLocation] = useState("")
  const [toLocation, setToLocation] = useState("")
  const [departureDate, setDepartureDate] = useState("")
  const [departureTime, setDepartureTime] = useState("")
  const [flexibleMinutes, setFlexibleMinutes] = useState("30")
  const [maxBudget, setMaxBudget] = useState("")
  const [passengerCount, setPassengerCount] = useState("1")
  const [specialRequirements, setSpecialRequirements] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Combine date and time
      const departureDateTime = new Date(`${departureDate}T${departureTime}`)

      const { error: insertError } = await supabase.from("passenger_intents").insert({
        passenger_id: user.id,
        from_location: fromLocation,
        to_location: toLocation,
        preferred_departure_time: departureDateTime.toISOString(),
        flexible_time_minutes: Number.parseInt(flexibleMinutes),
        max_budget: Number.parseFloat(maxBudget),
        passenger_count: Number.parseInt(passengerCount),
        special_requirements: specialRequirements || null,
      })

      if (insertError) throw insertError

      router.push("/dashboard/passenger")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/dashboard/passenger">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Declare Your Travel Intent</h2>
            <p className="text-gray-600">
              Tell us where you want to go and our AI solver will find the perfect driver match.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-blue-600" />
                Travel Details
              </CardTitle>
              <CardDescription>Provide your travel preferences and requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <div className="flex flex-col gap-6">
                  {/* Location Fields */}
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="fromLocation">From (Pickup Location)</Label>
                      <Input
                        id="fromLocation"
                        type="text"
                        placeholder="e.g., Downtown LA, 123 Main St"
                        required
                        value={fromLocation}
                        onChange={(e) => setFromLocation(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="toLocation">To (Destination)</Label>
                      <Input
                        id="toLocation"
                        type="text"
                        placeholder="e.g., Inglewood, LAX Airport"
                        required
                        value={toLocation}
                        onChange={(e) => setToLocation(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Time Fields */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="departureDate">Preferred Date</Label>
                      <Input
                        id="departureDate"
                        type="date"
                        required
                        min={new Date().toISOString().split("T")[0]}
                        value={departureDate}
                        onChange={(e) => setDepartureDate(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="departureTime">Preferred Time</Label>
                      <Input
                        id="departureTime"
                        type="time"
                        required
                        value={departureTime}
                        onChange={(e) => setDepartureTime(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="flexibleMinutes">Time Flexibility (minutes)</Label>
                    <Input
                      id="flexibleMinutes"
                      type="number"
                      min="0"
                      max="180"
                      placeholder="30"
                      value={flexibleMinutes}
                      onChange={(e) => setFlexibleMinutes(e.target.value)}
                    />
                    <p className="text-sm text-gray-500">
                      How flexible are you with departure time? (±{flexibleMinutes} minutes)
                    </p>
                  </div>

                  {/* Budget and Passengers */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="maxBudget" className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Maximum Budget
                      </Label>
                      <Input
                        id="maxBudget"
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="200.00"
                        required
                        value={maxBudget}
                        onChange={(e) => setMaxBudget(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="passengerCount" className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Number of Passengers
                      </Label>
                      <Input
                        id="passengerCount"
                        type="number"
                        min="1"
                        max="8"
                        required
                        value={passengerCount}
                        onChange={(e) => setPassengerCount(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Special Requirements */}
                  <div className="grid gap-2">
                    <Label htmlFor="specialRequirements">Special Requirements (Optional)</Label>
                    <Textarea
                      id="specialRequirements"
                      placeholder="e.g., Need wheelchair accessibility, pet-friendly, extra luggage space..."
                      value={specialRequirements}
                      onChange={(e) => setSpecialRequirements(e.target.value)}
                    />
                  </div>

                  {error && <p className="text-sm text-red-500">{error}</p>}

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Creating Intent..." : "Declare Travel Intent"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-green-600" />
                What Happens Next?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">1</span>
                  </div>
                  <p className="text-sm">Our AI solver analyzes your intent and searches for matching drivers</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">2</span>
                  </div>
                  <p className="text-sm">You'll receive notifications when potential matches are found</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">3</span>
                  </div>
                  <p className="text-sm">Review driver profiles and confirm your preferred match</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
