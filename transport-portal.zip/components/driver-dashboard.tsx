"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Car, CheckCircle, Clock, AlertCircle, DollarSign, MapPin, Calendar, Users, Star } from "lucide-react"
import Link from "next/link"
import { DashboardStats } from "@/components/dashboard-stats"

interface DriverDashboardProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    phone: string
    user_type: string
  }
  driverProfile: {
    id: string
    license_number: string
    vehicle_make: string
    vehicle_model: string
    vehicle_year: number
    vehicle_color: string
    vehicle_plate: string
    vehicle_capacity: number
    verification_status: string
  }
}

export default function DriverDashboard({ user, profile, driverProfile }: DriverDashboardProps) {
  const getVerificationBadge = () => {
    switch (driverProfile.verification_status) {
      case "approved":
        return (
          <Badge className="bg-green-100 text-green-800 border-green-200">
            <CheckCircle className="h-3 w-3 mr-1" />
            Verified Driver
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-200">
            <Clock className="h-3 w-3 mr-1" />
            Verification Pending
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="destructive">
            <AlertCircle className="h-3 w-3 mr-1" />
            Verification Required
          </Badge>
        )
      default:
        return <Badge variant="secondary">Status Unknown</Badge>
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid gap-8">
        {/* Welcome Section */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome back, {profile.full_name}!</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Manage your availability and connect with passengers who need rides along your route.
          </p>
          <div className="flex justify-center mt-4">{getVerificationBadge()}</div>
        </div>

        {/* Verification Status Alerts */}
        {driverProfile.verification_status === "pending" && (
          <Card className="border-yellow-200 bg-yellow-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-800">
                <Clock className="h-5 w-5" />
                Verification In Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-yellow-700 mb-4">
                Your driver profile is under review. You'll be able to accept rides once verification is complete. This
                usually takes 24-48 hours.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  Check Status
                </Button>
                <Button variant="outline" size="sm">
                  Contact Support
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {driverProfile.verification_status === "rejected" && (
          <Card className="border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-800">
                <AlertCircle className="h-5 w-5" />
                Action Required
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-700 mb-4">
                Your driver profile needs additional verification. Please contact support to resolve any issues and
                resubmit your documentation.
              </p>
              <Button variant="destructive">Contact Support</Button>
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Your Driving Overview</h2>
          <DashboardStats userType="driver" userId={user.id} />
        </div>

        {/* Vehicle Information */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Car className="h-6 w-6 text-blue-600" />
              Your Vehicle
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="col-span-2">
                <h3 className="font-bold text-xl text-gray-900 mb-2">
                  {driverProfile.vehicle_year} {driverProfile.vehicle_make} {driverProfile.vehicle_model}
                </h3>
                <p className="text-gray-600 mb-1">Color: {driverProfile.vehicle_color}</p>
                <p className="text-sm text-gray-500">License Plate: {driverProfile.vehicle_plate}</p>
                <p className="text-sm text-gray-500">License: {driverProfile.license_number}</p>
              </div>
              <div className="text-center">
                <div className="bg-white rounded-lg p-4 border">
                  <p className="text-sm text-gray-500 mb-1">Passenger Capacity</p>
                  <p className="text-3xl font-bold text-blue-600">{driverProfile.vehicle_capacity}</p>
                  <p className="text-xs text-gray-400">passengers</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card
              className={`cursor-pointer hover:shadow-lg transition-all duration-200 border-2 hover:border-green-200 ${
                driverProfile.verification_status !== "approved" ? "opacity-50 cursor-not-allowed" : ""
              }`}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Calendar className="h-5 w-5 text-green-600" />
                  </div>
                  Set Availability
                </CardTitle>
                <CardDescription>Declare when you're ready to drive</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  className="w-full"
                  disabled={driverProfile.verification_status !== "approved"}
                  asChild={driverProfile.verification_status === "approved"}
                >
                  {driverProfile.verification_status === "approved" ? (
                    <Link href="/availability/create">Update Availability</Link>
                  ) : (
                    "Verification Required"
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  View Matches
                </CardTitle>
                <CardDescription>See passenger requests that match your route</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/matches">Browse Matches</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <DollarSign className="h-5 w-5 text-purple-600" />
                  </div>
                  Earnings
                </CardTitle>
                <CardDescription>Track your income and payments</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/earnings">View Earnings</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Star className="h-5 w-5 text-yellow-600" />
                  </div>
                  Reviews
                </CardTitle>
                <CardDescription>See feedback from passengers</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/reviews">View Reviews</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Active Availability */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <MapPin className="h-6 w-6 text-green-600" />
              Current Availability
            </CardTitle>
            <CardDescription>Your active driving availability and route preferences</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No active availability</h3>
              <p className="text-gray-500 mb-6">Set your availability to start receiving passenger match requests</p>
              <Button
                disabled={driverProfile.verification_status !== "approved"}
                asChild={driverProfile.verification_status === "approved"}
              >
                {driverProfile.verification_status === "approved" ? (
                  <Link href="/availability/create">Set Your Availability</Link>
                ) : (
                  "Verification Required"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* How It Works for Drivers */}
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardHeader>
            <CardTitle className="text-center text-2xl">How Driver Matching Works</CardTitle>
            <CardDescription className="text-center">
              Earn money by helping passengers along your planned routes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">1. Set Availability</h3>
                <p className="text-gray-600">Declare when, where, and what routes you're planning to drive</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">2. Get Matched</h3>
                <p className="text-gray-600">Our AI finds passengers whose travel intents align with your route</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">3. Earn & Review</h3>
                <p className="text-gray-600">Complete rides, receive automatic payments, and build your reputation</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
