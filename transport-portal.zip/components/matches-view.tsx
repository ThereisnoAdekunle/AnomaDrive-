"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useState } from "react"
import { Car, User, LogOut, ArrowLeft, Search, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface MatchesViewProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    user_type: string
  }
  userIntents: any[]
  userAvailabilities: any[]
  existingMatches: any[]
}

export default function MatchesView({
  user,
  profile,
  userIntents,
  userAvailabilities,
  existingMatches,
}: MatchesViewProps) {
  const [matches, setMatches] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [selectedItem, setSelectedItem] = useState<string | null>(null)
  const router = useRouter()

  const handleSignOut = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  const findMatches = async (type: string, id: string) => {
    setLoading(true)
    setSelectedItem(id)

    try {
      const response = await fetch("/api/matches/find", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type, id }),
      })

      const data = await response.json()
      setMatches(data.matches || [])
    } catch (error) {
      console.error("Error finding matches:", error)
    } finally {
      setLoading(false)
    }
  }

  const respondToMatch = async (matchId: string, action: "accept" | "reject") => {
    try {
      const response = await fetch("/api/matches/respond", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ match_id: matchId, action }),
      })

      if (response.ok) {
        // Refresh the page to show updated matches
        window.location.reload()
      }
    } catch (error) {
      console.error("Error responding to match:", error)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      case "accepted":
        return <Badge className="bg-green-100 text-green-800">Accepted</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      case "completed":
        return <Badge className="bg-blue-100 text-blue-800">Completed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href={`/dashboard/${profile.user_type}`}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div className="flex items-center gap-2">
              <User className="h-5 w-5 text-gray-600" />
              <span className="text-sm font-medium">{profile.full_name}</span>
              <Badge variant="outline">{profile.user_type}</Badge>
            </div>
            <Button variant="ghost" size="sm" onClick={handleSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Smart Matching</h2>
          <p className="text-gray-600">Find perfect matches using our AI-powered solver agent</p>
        </div>

        <Tabs defaultValue="find-matches" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="find-matches">Find New Matches</TabsTrigger>
            <TabsTrigger value="existing-matches">Existing Matches</TabsTrigger>
          </TabsList>

          <TabsContent value="find-matches" className="space-y-6">
            <div className="grid gap-6">
              {/* User's Intents/Availabilities */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5 text-blue-600" />
                    {profile.user_type === "passenger" ? "Your Travel Intents" : "Your Availability"}
                  </CardTitle>
                  <CardDescription>Click on any item to find potential matches</CardDescription>
                </CardHeader>
                <CardContent>
                  {profile.user_type === "passenger" ? (
                    <div className="space-y-4">
                      {userIntents.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">
                          No active travel intents.{" "}
                          <Link href="/intents/create" className="text-blue-600 underline">
                            Create one
                          </Link>{" "}
                          to find matches.
                        </p>
                      ) : (
                        userIntents.map((intent) => (
                          <Card
                            key={intent.id}
                            className="cursor-pointer hover:shadow-md transition-shadow"
                            onClick={() => findMatches("passenger_intent", intent.id)}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">
                                    {intent.from_location} → {intent.to_location}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {formatDate(intent.preferred_departure_time)} • ${intent.max_budget} •{" "}
                                    {intent.passenger_count} passengers
                                  </p>
                                </div>
                                <Button size="sm" variant="outline">
                                  Find Matches
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {userAvailabilities.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">
                          No active availability.{" "}
                          <Link href="/availability/create" className="text-blue-600 underline">
                            Set your availability
                          </Link>{" "}
                          to find matches.
                        </p>
                      ) : (
                        userAvailabilities.map((availability) => (
                          <Card
                            key={availability.id}
                            className="cursor-pointer hover:shadow-md transition-shadow"
                            onClick={() => findMatches("driver_availability", availability.id)}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium">
                                    {availability.from_location} → {availability.to_location}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {formatDate(availability.available_from)} -{" "}
                                    {formatDate(availability.available_until)} • ${availability.min_price}-$
                                    {availability.max_price} • {availability.available_seats} seats
                                  </p>
                                </div>
                                <Button size="sm" variant="outline">
                                  Find Matches
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Match Results */}
              {selectedItem && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      Match Results
                    </CardTitle>
                    <CardDescription>
                      {loading ? "Finding matches..." : `Found ${matches.length} potential matches`}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {loading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                        <p className="text-gray-500 mt-2">Analyzing compatibility...</p>
                      </div>
                    ) : matches.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No matches found at this time.</p>
                        <p className="text-sm text-gray-400">Try adjusting your preferences or check back later.</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {matches.map((match) => (
                          <Card
                            key={`${match.passenger_intent_id}-${match.driver_availability_id}`}
                            className="border-green-200"
                          >
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center gap-2">
                                  <Badge className="bg-green-100 text-green-800">
                                    {Math.round(match.match_score * 100)}% Match
                                  </Badge>
                                  <span className="text-sm font-medium">${match.suggested_price}</span>
                                </div>
                                <div className="text-sm text-gray-500">{formatDate(match.pickup_time)}</div>
                              </div>

                              {profile.user_type === "passenger" ? (
                                <div>
                                  <p className="font-medium">{match.driver?.full_name}</p>
                                  <p className="text-sm text-gray-600">
                                    {match.vehicle?.vehicle_year} {match.vehicle?.vehicle_make}{" "}
                                    {match.vehicle?.vehicle_model} ({match.vehicle?.vehicle_color})
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    Route: {match.availability?.from_location} → {match.availability?.to_location}
                                  </p>
                                </div>
                              ) : (
                                <div>
                                  <p className="font-medium">{match.passenger?.full_name}</p>
                                  <p className="text-sm text-gray-600">{match.intent?.passenger_count} passenger(s)</p>
                                  <p className="text-sm text-gray-500">
                                    Route: {match.intent?.from_location} → {match.intent?.to_location}
                                  </p>
                                </div>
                              )}

                              <div className="flex gap-2 mt-3">
                                <Button size="sm" className="flex-1">
                                  Contact & Accept
                                </Button>
                                <Button size="sm" variant="outline">
                                  View Details
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="existing-matches" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Matches</CardTitle>
                <CardDescription>All your match requests and responses</CardDescription>
              </CardHeader>
              <CardContent>
                {existingMatches.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No matches yet</p>
                    <p className="text-sm text-gray-400">Start by finding matches for your intents or availability</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {existingMatches.map((match) => (
                      <Card key={match.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              {getStatusBadge(match.status)}
                              <span className="text-sm font-medium">{Math.round(match.match_score * 100)}% Match</span>
                            </div>
                            <div className="text-sm text-gray-500">{formatDate(match.created_at)}</div>
                          </div>

                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium text-gray-700">Route</p>
                              <p className="text-sm">
                                {match.passenger_intents.from_location} → {match.passenger_intents.to_location}
                              </p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Price</p>
                              <p className="text-sm">${match.agreed_price || match.suggested_price}</p>
                            </div>
                          </div>

                          {match.status === "pending" && (
                            <div className="flex gap-2 mt-3">
                              <Button size="sm" onClick={() => respondToMatch(match.id, "accept")} className="flex-1">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Accept
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => respondToMatch(match.id, "reject")}
                                className="flex-1"
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Decline
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
