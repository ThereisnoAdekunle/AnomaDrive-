"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Car, User } from "lucide-react"

interface OnboardingFormProps {
  user: {
    id: string
    email?: string
  }
}

export default function OnboardingForm({ user }: OnboardingFormProps) {
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // Basic profile data
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")
  const [userType, setUserType] = useState("passenger")

  // Driver-specific data
  const [licenseNumber, setLicenseNumber] = useState("")
  const [licenseExpiry, setLicenseExpiry] = useState("")
  const [vehicleMake, setVehicleMake] = useState("")
  const [vehicleModel, setVehicleModel] = useState("")
  const [vehicleYear, setVehicleYear] = useState("")
  const [vehicleColor, setVehicleColor] = useState("")
  const [vehiclePlate, setVehiclePlate] = useState("")
  const [vehicleCapacity, setVehicleCapacity] = useState("4")

  const handleBasicProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Update profile
      const { error: profileError } = await supabase.from("profiles").upsert({
        id: user.id,
        email: user.email,
        full_name: fullName,
        phone: phone,
        user_type: userType,
      })

      if (profileError) throw profileError

      if (userType === "driver") {
        setStep(2)
      } else {
        router.push("/dashboard/passenger")
      }
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleDriverProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Create driver profile
      const { error: driverError } = await supabase.from("driver_profiles").insert({
        id: user.id,
        license_number: licenseNumber,
        license_expiry: licenseExpiry,
        vehicle_make: vehicleMake,
        vehicle_model: vehicleModel,
        vehicle_year: Number.parseInt(vehicleYear),
        vehicle_color: vehicleColor,
        vehicle_plate: vehiclePlate.toUpperCase(),
        vehicle_capacity: Number.parseInt(vehicleCapacity),
      })

      if (driverError) throw driverError

      router.push("/dashboard/driver")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
      <div className="w-full max-w-2xl">
        <div className="flex flex-col gap-6">
          {/* Logo */}
          <div className="flex items-center justify-center gap-2 mb-4">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>

          {/* Progress indicator */}
          <div className="flex items-center justify-center gap-4 mb-6">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 1 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              1
            </div>
            {userType === "driver" && (
              <>
                <div className="w-12 h-0.5 bg-gray-200"></div>
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step >= 2 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
                  }`}
                >
                  2
                </div>
              </>
            )}
          </div>

          {step === 1 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Complete Your Profile</CardTitle>
                <CardDescription>Tell us about yourself to get started</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBasicProfile}>
                  <div className="flex flex-col gap-6">
                    <div className="grid gap-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        type="text"
                        placeholder="John Doe"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                      />
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+1 (555) 123-4567"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                      />
                    </div>

                    <div className="grid gap-3">
                      <Label>Account Type</Label>
                      <RadioGroup value={userType} onValueChange={setUserType}>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="passenger" id="passenger" />
                          <Label htmlFor="passenger" className="flex items-center gap-2">
                            <User className="h-4 w-4" />
                            Passenger - Find rides and declare travel intents
                          </Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="driver" id="driver" />
                          <Label htmlFor="driver" className="flex items-center gap-2">
                            <Car className="h-4 w-4" />
                            Driver - Offer rides and earn money
                          </Label>
                        </div>
                      </RadioGroup>
                    </div>

                    {error && <p className="text-sm text-red-500">{error}</p>}

                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? "Saving..." : userType === "driver" ? "Continue to Vehicle Info" : "Complete Setup"}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {step === 2 && userType === "driver" && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Vehicle & License Information</CardTitle>
                <CardDescription>We need to verify your driving credentials and vehicle details</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleDriverProfile}>
                  <div className="flex flex-col gap-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="licenseNumber">Driver's License Number</Label>
                        <Input
                          id="licenseNumber"
                          type="text"
                          placeholder="D1234567"
                          required
                          value={licenseNumber}
                          onChange={(e) => setLicenseNumber(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="licenseExpiry">License Expiry Date</Label>
                        <Input
                          id="licenseExpiry"
                          type="date"
                          required
                          value={licenseExpiry}
                          onChange={(e) => setLicenseExpiry(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="vehicleMake">Vehicle Make</Label>
                        <Input
                          id="vehicleMake"
                          type="text"
                          placeholder="Toyota"
                          required
                          value={vehicleMake}
                          onChange={(e) => setVehicleMake(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="vehicleModel">Vehicle Model</Label>
                        <Input
                          id="vehicleModel"
                          type="text"
                          placeholder="Camry"
                          required
                          value={vehicleModel}
                          onChange={(e) => setVehicleModel(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="vehicleYear">Year</Label>
                        <Input
                          id="vehicleYear"
                          type="number"
                          placeholder="2020"
                          min="2000"
                          max="2025"
                          required
                          value={vehicleYear}
                          onChange={(e) => setVehicleYear(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="vehicleColor">Color</Label>
                        <Input
                          id="vehicleColor"
                          type="text"
                          placeholder="Silver"
                          required
                          value={vehicleColor}
                          onChange={(e) => setVehicleColor(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="vehicleCapacity">Passenger Capacity</Label>
                        <Input
                          id="vehicleCapacity"
                          type="number"
                          min="1"
                          max="8"
                          required
                          value={vehicleCapacity}
                          onChange={(e) => setVehicleCapacity(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="vehiclePlate">License Plate</Label>
                      <Input
                        id="vehiclePlate"
                        type="text"
                        placeholder="ABC123"
                        required
                        value={vehiclePlate}
                        onChange={(e) => setVehiclePlate(e.target.value)}
                      />
                    </div>

                    {error && <p className="text-sm text-red-500">{error}</p>}

                    <div className="flex gap-3">
                      <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                        Back
                      </Button>
                      <Button type="submit" className="flex-1" disabled={isLoading}>
                        {isLoading ? "Creating Profile..." : "Complete Registration"}
                      </Button>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
