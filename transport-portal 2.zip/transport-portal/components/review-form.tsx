"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Car, ArrowLeft, Star, CheckCircle } from "lucide-react"
import Link from "next/link"

interface ReviewFormProps {
  user: {
    id: string
    email?: string
  }
  rideSession: any
  passengerProfile: any
  driverProfile: any
  isPassenger: boolean
  existingReview: any
}

export default function ReviewForm({
  user,
  rideSession,
  passengerProfile,
  driverProfile,
  isPassenger,
  existingReview,
}: ReviewFormProps) {
  const [rating, setRating] = useState(existingReview?.rating || 0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [title, setTitle] = useState(existingReview?.title || "")
  const [comment, setComment] = useState(existingReview?.comment || "")
  const [isAnonymous, setIsAnonymous] = useState(existingReview?.is_anonymous || false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [submitted, setSubmitted] = useState(!!existingReview)

  // Category ratings
  const [categoryRatings, setCategoryRatings] = useState({
    punctuality: existingReview?.categories?.punctuality || 0,
    cleanliness: existingReview?.categories?.cleanliness || 0,
    communication: existingReview?.categories?.communication || 0,
    safety: existingReview?.categories?.safety || 0,
    vehicle_condition: existingReview?.categories?.vehicle_condition || 0,
  })

  const router = useRouter()

  const revieweeProfile = isPassenger ? driverProfile : passengerProfile
  const revieweeType = isPassenger ? "driver" : "passenger"

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (rating === 0) {
      setError("Please select a rating")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const categories = Object.entries(categoryRatings)
        .filter(([_, rating]) => rating > 0)
        .map(([name, rating]) => ({ name, rating }))

      const response = await fetch("/api/reviews/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ride_session_id: rideSession.id,
          rating,
          title,
          comment,
          categories,
          is_anonymous: isAnonymous,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to submit review")
      }

      setSubmitted(true)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  const StarRating = ({
    value,
    onChange,
    onHover,
    size = "w-8 h-8",
  }: {
    value: number
    onChange: (rating: number) => void
    onHover?: (rating: number) => void
    size?: string
  }) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            className={`${size} transition-colors`}
            onClick={() => onChange(star)}
            onMouseEnter={() => onHover?.(star)}
            onMouseLeave={() => onHover?.(0)}
          >
            <Star
              className={`w-full h-full ${
                star <= (hoveredRating || value) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
              }`}
            />
          </button>
        ))}
      </div>
    )
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        {/* Header */}
        <header className="border-b bg-white/80 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Car className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
            </div>
            <Button variant="ghost" asChild>
              <Link href="/matches">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Matches
              </Link>
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-2xl mx-auto">
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-8 text-center">
                <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-green-900 mb-2">Review Submitted!</h2>
                <p className="text-green-700 mb-6">
                  Thank you for your feedback. Your review helps improve the experience for everyone.
                </p>
                <Button onClick={() => router.push("/matches")}>Return to Matches</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/matches">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Matches
            </Link>
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Rate Your Experience</h2>
            <p className="text-gray-600">Share your feedback about your ride with {revieweeProfile?.full_name}</p>
          </div>

          {/* Ride Details */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Ride Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-700">Route</p>
                  <p className="text-sm">
                    {rideSession.intent_matches.passenger_intents.from_location} →{" "}
                    {rideSession.intent_matches.passenger_intents.to_location}
                  </p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700">Date</p>
                  <p className="text-sm">{formatDate(rideSession.actual_pickup_time || rideSession.created_at)}</p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-sm font-medium text-gray-700">
                  {revieweeType === "driver" ? "Driver" : "Passenger"}
                </p>
                <p className="text-sm">{revieweeProfile?.full_name}</p>
              </div>
            </CardContent>
          </Card>

          {/* Review Form */}
          <Card>
            <CardHeader>
              <CardTitle>Your Review</CardTitle>
              <CardDescription>Rate your experience and help others make informed decisions</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Overall Rating */}
                <div className="space-y-2">
                  <Label>Overall Rating</Label>
                  <div className="flex items-center gap-4">
                    <StarRating value={rating} onChange={setRating} onHover={setHoveredRating} />
                    <span className="text-sm text-gray-600">
                      {rating > 0 && (
                        <>
                          {rating === 1 && "Poor"}
                          {rating === 2 && "Fair"}
                          {rating === 3 && "Good"}
                          {rating === 4 && "Very Good"}
                          {rating === 5 && "Excellent"}
                        </>
                      )}
                    </span>
                  </div>
                </div>

                {/* Category Ratings (for driver reviews) */}
                {isPassenger && (
                  <div className="space-y-4">
                    <Label>Detailed Ratings</Label>
                    <div className="grid gap-4">
                      {Object.entries(categoryRatings).map(([category, value]) => (
                        <div key={category} className="flex items-center justify-between">
                          <span className="text-sm font-medium capitalize">{category.replace("_", " ")}</span>
                          <StarRating
                            value={value}
                            onChange={(rating) => setCategoryRatings((prev) => ({ ...prev, [category]: rating }))}
                            size="w-5 h-5"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Review Title */}
                <div className="space-y-2">
                  <Label htmlFor="title">Review Title (Optional)</Label>
                  <Input
                    id="title"
                    placeholder="Summarize your experience"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                {/* Review Comment */}
                <div className="space-y-2">
                  <Label htmlFor="comment">Your Review (Optional)</Label>
                  <Textarea
                    id="comment"
                    placeholder="Share details about your experience..."
                    rows={4}
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                  />
                </div>

                {/* Anonymous Option */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="anonymous"
                    checked={isAnonymous}
                    onCheckedChange={(checked) => setIsAnonymous(checked as boolean)}
                  />
                  <Label htmlFor="anonymous" className="text-sm">
                    Submit this review anonymously
                  </Label>
                </div>

                {error && <p className="text-sm text-red-500">{error}</p>}

                <Button type="submit" disabled={isLoading || rating === 0} className="w-full">
                  {isLoading ? "Submitting..." : "Submit Review"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
