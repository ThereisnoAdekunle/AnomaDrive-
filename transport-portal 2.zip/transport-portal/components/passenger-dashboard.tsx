"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Clock, DollarSign, Plus, Car, History, Users } from "lucide-react"
import Link from "next/link"
import { DashboardStats } from "@/components/dashboard-stats"

interface PassengerDashboardProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    phone: string
    user_type: string
  }
}

export default function PassengerDashboard({ user, profile }: PassengerDashboardProps) {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid gap-8">
        {/* Welcome Section */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome back, {profile.full_name}!</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Declare your travel intent and let our intelligent solver find the perfect ride match for you.
          </p>
        </div>

        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Your Travel Overview</h2>
          <DashboardStats userType="passenger" userId={user.id} />
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2 hover:border-blue-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Plus className="h-5 w-5 text-blue-600" />
                  </div>
                  Declare New Intent
                </CardTitle>
                <CardDescription>Tell us where you want to go and when</CardDescription>
              </CardHeader>
              <CardContent>
                <Button className="w-full" size="lg" asChild>
                  <Link href="/intents/create">Create Travel Intent</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Users className="h-5 w-5 text-green-600" />
                  </div>
                  View Matches
                </CardTitle>
                <CardDescription>See potential driver matches for your intents</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full bg-transparent" size="lg" asChild>
                  <Link href="/matches">Browse Matches</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <History className="h-5 w-5 text-purple-600" />
                  </div>
                  Ride History
                </CardTitle>
                <CardDescription>View your completed trips and reviews</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="outline" className="w-full bg-transparent" size="lg" asChild>
                  <Link href="/history">View History</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Active Intents */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <Clock className="h-6 w-6 text-orange-600" />
              Active Travel Intents
            </CardTitle>
            <CardDescription>Your current travel requests awaiting matches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No active intents</h3>
              <p className="text-gray-500 mb-6">
                Create your first travel intent to get started with smart ride matching
              </p>
              <Button asChild>
                <Link href="/intents/create">Create Your First Intent</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* How It Works */}
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-center text-2xl">How Intent Matching Works</CardTitle>
            <CardDescription className="text-center">
              Our AI-powered system connects you with the perfect driver
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">1. Declare Intent</h3>
                <p className="text-gray-600">
                  Tell us your destination, preferred time, budget, and any special requirements
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Car className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">2. Smart Matching</h3>
                <p className="text-gray-600">Our AI solver analyzes driver availability and finds optimal matches</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-lg mb-3">3. Secure Journey</h3>
                <p className="text-gray-600">Enjoy your ride with automatic payment processing and safety features</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
