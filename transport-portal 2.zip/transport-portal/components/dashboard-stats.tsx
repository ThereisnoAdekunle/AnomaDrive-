"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Car, MapPin, DollarSign, Star, TrendingUp, Clock, Users, Route } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface DashboardStats {
  totalRides: number
  activeIntents: number
  totalEarnings: number
  averageRating: number
  completionRate: number
  responseTime: string
}

interface Props {
  userType: "passenger" | "driver"
  userId: string
}

export function DashboardStats({ userType, userId }: Props) {
  const [stats, setStats] = useState<DashboardStats>({
    totalRides: 0,
    activeIntents: 0,
    totalEarnings: 0,
    averageRating: 0,
    completionRate: 0,
    responseTime: "0 min",
  })
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const fetchStats = async () => {
      try {
        if (userType === "driver") {
          // Fetch driver stats
          const { data: rides } = await supabase
            .from("ride_sessions")
            .select("*")
            .eq("driver_id", userId)
            .eq("status", "completed")

          const { data: availability } = await supabase
            .from("driver_availability")
            .select("*")
            .eq("driver_id", userId)
            .eq("status", "active")

          const { data: earnings } = await supabase
            .from("transactions")
            .select("driver_amount")
            .eq("driver_id", userId)
            .eq("status", "completed")

          const { data: reviews } = await supabase.from("reviews").select("overall_rating").eq("driver_id", userId)

          const totalEarnings = earnings?.reduce((sum, t) => sum + (t.driver_amount || 0), 0) || 0
          const avgRating = reviews?.length ? reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length : 0

          setStats({
            totalRides: rides?.length || 0,
            activeIntents: availability?.length || 0,
            totalEarnings,
            averageRating: avgRating,
            completionRate: rides?.length ? (rides.length / (rides.length + 2)) * 100 : 0,
            responseTime: "2 min",
          })
        } else {
          // Fetch passenger stats
          const { data: rides } = await supabase.from("ride_sessions").select("*").eq("passenger_id", userId)

          const { data: intents } = await supabase
            .from("passenger_intents")
            .select("*")
            .eq("passenger_id", userId)
            .eq("status", "active")

          const { data: payments } = await supabase
            .from("transactions")
            .select("amount")
            .eq("passenger_id", userId)
            .eq("status", "completed")

          const totalSpent = payments?.reduce((sum, p) => sum + (p.amount || 0), 0) || 0
          const completedRides = rides?.filter((r) => r.status === "completed").length || 0

          setStats({
            totalRides: completedRides,
            activeIntents: intents?.length || 0,
            totalEarnings: totalSpent,
            averageRating: 4.8, // Passenger satisfaction score
            completionRate: rides?.length ? (completedRides / rides.length) * 100 : 0,
            responseTime: "1.5 min",
          })
        }
      } catch (error) {
        console.error("Error fetching stats:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [userType, userId, supabase])

  const statCards =
    userType === "driver"
      ? [
          {
            title: "Total Rides",
            value: stats.totalRides.toString(),
            description: "Completed successfully",
            icon: Car,
            color: "text-blue-600",
          },
          {
            title: "Active Availability",
            value: stats.activeIntents.toString(),
            description: "Current offerings",
            icon: MapPin,
            color: "text-green-600",
          },
          {
            title: "Total Earnings",
            value: `$${stats.totalEarnings.toFixed(2)}`,
            description: "All time earnings",
            icon: DollarSign,
            color: "text-emerald-600",
          },
          {
            title: "Average Rating",
            value: stats.averageRating.toFixed(1),
            description: "From passengers",
            icon: Star,
            color: "text-yellow-600",
          },
          {
            title: "Completion Rate",
            value: `${stats.completionRate.toFixed(1)}%`,
            description: "Successful rides",
            icon: TrendingUp,
            color: "text-purple-600",
          },
          {
            title: "Avg Response Time",
            value: stats.responseTime,
            description: "To match requests",
            icon: Clock,
            color: "text-orange-600",
          },
        ]
      : [
          {
            title: "Total Rides",
            value: stats.totalRides.toString(),
            description: "Completed trips",
            icon: Route,
            color: "text-blue-600",
          },
          {
            title: "Active Intents",
            value: stats.activeIntents.toString(),
            description: "Pending requests",
            icon: MapPin,
            color: "text-green-600",
          },
          {
            title: "Total Spent",
            value: `$${stats.totalEarnings.toFixed(2)}`,
            description: "On transportation",
            icon: DollarSign,
            color: "text-emerald-600",
          },
          {
            title: "Satisfaction Score",
            value: stats.averageRating.toFixed(1),
            description: "Your experience rating",
            icon: Star,
            color: "text-yellow-600",
          },
          {
            title: "Success Rate",
            value: `${stats.completionRate.toFixed(1)}%`,
            description: "Completed bookings",
            icon: TrendingUp,
            color: "text-purple-600",
          },
          {
            title: "Avg Match Time",
            value: stats.responseTime,
            description: "To find drivers",
            icon: Users,
            color: "text-orange-600",
          },
        ]

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 bg-gray-200 rounded w-24"></div>
              <div className="h-4 w-4 bg-gray-200 rounded"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-gray-200 rounded w-16 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-32"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {statCards.map((stat, index) => {
        const Icon = stat.icon
        return (
          <Card key={index} className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
              <p className="text-xs text-gray-500 mt-1">{stat.description}</p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
