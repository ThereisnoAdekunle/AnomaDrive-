"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Car, ArrowLeft, CreditCard, Shield, Clock, CheckCircle, DollarSign } from "lucide-react"
import Link from "next/link"

interface PaymentFlowProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    user_type: string
  }
  match: any
  driverProfile: any
  existingTransaction: any
}

export default function PaymentFlow({ user, profile, match, driverProfile, existingTransaction }: PaymentFlowProps) {
  const [step, setStep] = useState(existingTransaction ? 2 : 1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [paymentIntent, setPaymentIntent] = useState<any>(null)
  const [transaction, setTransaction] = useState(existingTransaction)
  const router = useRouter()

  // Mock payment method form
  const [cardNumber, setCardNumber] = useState("")
  const [expiryDate, setExpiryDate] = useState("")
  const [cvv, setCvv] = useState("")
  const [cardholderName, setCardholderName] = useState(profile.full_name)

  const amount = match.agreed_price || match.suggested_price
  const platformFee = Math.round(amount * 0.05 * 100) / 100
  const driverEarnings = Math.round((amount - platformFee) * 100) / 100

  const createPaymentIntent = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/payments/create-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ match_id: match.id }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create payment intent")
      }

      setPaymentIntent(data.payment_intent)
      setTransaction(data.transaction)
      setStep(2)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const authorizePayment = async () => {
    setIsLoading(true)
    setError(null)

    try {
      // In a real implementation, you would use Stripe Elements or similar
      // to securely collect payment method details
      const mockPaymentMethodId = `pm_${Math.random().toString(36).substr(2, 9)}`

      const response = await fetch("/api/payments/authorize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          transaction_id: transaction.id,
          payment_method_id: mockPaymentMethodId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Payment authorization failed")
      }

      setTransaction(data.transaction)
      setStep(3)
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/matches">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Matches
            </Link>
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Secure Payment</h2>
            <p className="text-gray-600">Complete your payment to confirm your ride with {driverProfile?.full_name}</p>
          </div>

          {/* Progress indicator */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 1 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              1
            </div>
            <div className="w-12 h-0.5 bg-gray-200"></div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 2 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              2
            </div>
            <div className="w-12 h-0.5 bg-gray-200"></div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                step >= 3 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
              }`}
            >
              3
            </div>
          </div>

          {/* Step 1: Review Ride Details */}
          {step === 1 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Car className="h-5 w-5 text-blue-600" />
                    Ride Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700">From</p>
                      <p className="text-sm">{match.passenger_intents.from_location}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">To</p>
                      <p className="text-sm">{match.passenger_intents.to_location}</p>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Pickup Time</p>
                      <p className="text-sm">{formatDate(match.pickup_time)}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Passengers</p>
                      <p className="text-sm">{match.passenger_intents.passenger_count}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Driver</p>
                    <p className="text-sm">{driverProfile?.full_name}</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-green-600" />
                    Payment Breakdown
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span>Ride Cost</span>
                    <span>${amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Platform Fee (5%)</span>
                    <span>${platformFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Driver Earnings</span>
                    <span>${driverEarnings.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between font-semibold">
                      <span>Total</span>
                      <span>${amount.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-blue-900">Secure Escrow Payment</h3>
                      <p className="text-sm text-blue-700">
                        Your payment is held securely until the ride is completed. Funds are only released to the driver
                        after you confirm arrival.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {error && <p className="text-sm text-red-500 text-center">{error}</p>}

              <Button onClick={createPaymentIntent} disabled={isLoading} className="w-full">
                {isLoading ? "Processing..." : "Continue to Payment"}
              </Button>
            </div>
          )}

          {/* Step 2: Payment Method */}
          {step === 2 && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5 text-blue-600" />
                    Payment Method
                  </CardTitle>
                  <CardDescription>Enter your payment details to authorize the transaction</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="cardNumber">Card Number</Label>
                      <Input
                        id="cardNumber"
                        placeholder="1234 5678 9012 3456"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="expiryDate">Expiry Date</Label>
                        <Input
                          id="expiryDate"
                          placeholder="MM/YY"
                          value={expiryDate}
                          onChange={(e) => setExpiryDate(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="cvv">CVV</Label>
                        <Input id="cvv" placeholder="123" value={cvv} onChange={(e) => setCvv(e.target.value)} />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="cardholderName">Cardholder Name</Label>
                      <Input
                        id="cardholderName"
                        value={cardholderName}
                        onChange={(e) => setCardholderName(e.target.value)}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-yellow-600 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-yellow-900">Authorization Only</h3>
                      <p className="text-sm text-yellow-700">
                        We'll authorize ${amount.toFixed(2)} on your card but won't charge you until the ride is
                        completed and confirmed.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {error && <p className="text-sm text-red-500 text-center">{error}</p>}

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                  Back
                </Button>
                <Button onClick={authorizePayment} disabled={isLoading} className="flex-1">
                  {isLoading ? "Authorizing..." : "Authorize Payment"}
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Payment Authorized */}
          {step === 3 && (
            <div className="space-y-6">
              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-6 text-center">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-green-900 mb-2">Payment Authorized!</h3>
                  <p className="text-green-700">
                    Your payment of ${amount.toFixed(2)} has been authorized and is held securely in escrow.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>What Happens Next?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-medium text-blue-600">1</span>
                      </div>
                      <div>
                        <p className="font-medium">Contact Your Driver</p>
                        <p className="text-sm text-gray-600">
                          Coordinate pickup details with {driverProfile?.full_name}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-medium text-blue-600">2</span>
                      </div>
                      <div>
                        <p className="font-medium">Enjoy Your Ride</p>
                        <p className="text-sm text-gray-600">Your payment is safely held until the ride is completed</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-xs font-medium text-blue-600">3</span>
                      </div>
                      <div>
                        <p className="font-medium">Confirm Completion</p>
                        <p className="text-sm text-gray-600">
                          Payment is released to the driver once you confirm arrival
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={() => router.push("/matches")} className="w-full">
                Return to Matches
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
