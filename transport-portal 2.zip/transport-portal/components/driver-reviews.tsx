"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useState, useEffect } from "react"
import { Star, User, ChevronLeft, ChevronRight } from "lucide-react"

interface DriverReviewsProps {
  driverId: string
  showTitle?: boolean
}

export default function DriverReviews({ driverId, showTitle = true }: DriverReviewsProps) {
  const [reviews, setReviews] = useState<any[]>([])
  const [summary, setSummary] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [pagination, setPagination] = useState<any>(null)

  useEffect(() => {
    fetchReviews()
  }, [driverId, currentPage])

  const fetchReviews = async () => {
    setLoading(true)
    try {
      const response = await fetch(`/api/reviews/driver/${driverId}?page=${currentPage}&limit=5`)
      const data = await response.json()

      setReviews(data.reviews)
      setSummary(data.summary)
      setPagination(data.pagination)
    } catch (error) {
      console.error("Error fetching reviews:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString()
  }

  const StarDisplay = ({ rating, size = "w-4 h-4" }: { rating: number; size?: string }) => {
    return (
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`${size} ${star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
          />
        ))}
      </div>
    )
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {showTitle && (
        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Driver Reviews</h3>
          <p className="text-gray-600">See what passengers are saying</p>
        </div>
      )}

      {/* Rating Summary */}
      {summary && summary.total_reviews > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5 text-yellow-400" />
              Rating Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-gray-900 mb-2">{summary.average_rating.toFixed(1)}</div>
                <StarDisplay rating={Math.round(summary.average_rating)} size="w-6 h-6" />
                <p className="text-sm text-gray-600 mt-2">
                  Based on {summary.total_reviews} review{summary.total_reviews !== 1 ? "s" : ""}
                </p>
              </div>
              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map((stars) => {
                  const count =
                    summary[
                      `${stars === 1 ? "one" : stars === 2 ? "two" : stars === 3 ? "three" : stars === 4 ? "four" : "five"}_star_count`
                    ]
                  const percentage = summary.total_reviews > 0 ? (count / summary.total_reviews) * 100 : 0

                  return (
                    <div key={stars} className="flex items-center gap-2">
                      <span className="text-sm w-8">{stars}</span>
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div className="bg-yellow-400 h-2 rounded-full" style={{ width: `${percentage}%` }}></div>
                      </div>
                      <span className="text-sm text-gray-600 w-8">{count}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Individual Reviews */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reviews</CardTitle>
          <CardDescription>
            {reviews.length === 0 ? "No reviews yet" : `Showing ${reviews.length} of ${pagination?.total || 0} reviews`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {reviews.length === 0 ? (
            <div className="text-center py-8">
              <User className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No reviews yet</p>
              <p className="text-sm text-gray-400">Reviews will appear here after completed rides</p>
            </div>
          ) : (
            <div className="space-y-6">
              {reviews.map((review) => (
                <div key={review.id} className="border-b border-gray-200 last:border-b-0 pb-6 last:pb-0">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {review.is_anonymous ? "Anonymous" : review.profiles?.full_name || "Anonymous"}
                        </p>
                        <p className="text-sm text-gray-500">{formatDate(review.created_at)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <StarDisplay rating={review.rating} />
                      <Badge variant="outline">{review.rating}/5</Badge>
                    </div>
                  </div>

                  {review.title && <h4 className="font-semibold text-gray-900 mb-2">{review.title}</h4>}

                  {review.comment && <p className="text-gray-700 mb-3">{review.comment}</p>}

                  {review.review_categories && review.review_categories.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {review.review_categories.map((category: any) => (
                        <div key={category.category_name} className="text-sm">
                          <span className="text-gray-600 capitalize">{category.category_name.replace("_", " ")}:</span>
                          <div className="flex items-center gap-1 mt-1">
                            <StarDisplay rating={category.rating} size="w-3 h-3" />
                            <span className="text-xs text-gray-500">{category.rating}/5</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Pagination */}
          {pagination && pagination.totalPages > 1 && (
            <div className="flex items-center justify-between mt-6 pt-6 border-t">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Previous
              </Button>
              <span className="text-sm text-gray-600">
                Page {currentPage} of {pagination.totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.min(pagination.totalPages, prev + 1))}
                disabled={currentPage === pagination.totalPages}
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
