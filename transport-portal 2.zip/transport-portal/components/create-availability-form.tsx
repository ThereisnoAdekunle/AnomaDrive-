"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { MapPin, Clock, DollarSign, Users, ArrowLeft, Car } from "lucide-react"
import Link from "next/link"

interface CreateAvailabilityFormProps {
  user: {
    id: string
    email?: string
  }
  profile: {
    id: string
    full_name: string
    user_type: string
  }
  driverProfile: {
    vehicle_capacity: number
  }
}

export default function CreateAvailabilityForm({ user, profile, driverProfile }: CreateAvailabilityFormProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  // Form data
  const [fromLocation, setFromLocation] = useState("")
  const [toLocation, setToLocation] = useState("")
  const [availableFromDate, setAvailableFromDate] = useState("")
  const [availableFromTime, setAvailableFromTime] = useState("")
  const [availableUntilDate, setAvailableUntilDate] = useState("")
  const [availableUntilTime, setAvailableUntilTime] = useState("")
  const [minPrice, setMinPrice] = useState("")
  const [maxPrice, setMaxPrice] = useState("")
  const [availableSeats, setAvailableSeats] = useState(driverProfile.vehicle_capacity.toString())
  const [routeFlexibility, setRouteFlexibility] = useState("exact")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      const supabase = createClient()

      // Combine date and time
      const availableFromDateTime = new Date(`${availableFromDate}T${availableFromTime}`)
      const availableUntilDateTime = new Date(`${availableUntilDate}T${availableUntilTime}`)

      // Validate dates
      if (availableUntilDateTime <= availableFromDateTime) {
        throw new Error("End time must be after start time")
      }

      if (Number.parseFloat(maxPrice) < Number.parseFloat(minPrice)) {
        throw new Error("Maximum price must be greater than minimum price")
      }

      const { error: insertError } = await supabase.from("driver_availability").insert({
        driver_id: user.id,
        from_location: fromLocation,
        to_location: toLocation,
        available_from: availableFromDateTime.toISOString(),
        available_until: availableUntilDateTime.toISOString(),
        min_price: Number.parseFloat(minPrice),
        max_price: Number.parseFloat(maxPrice),
        available_seats: Number.parseInt(availableSeats),
        route_flexibility: routeFlexibility,
      })

      if (insertError) throw insertError

      router.push("/dashboard/driver")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <Button variant="ghost" asChild>
            <Link href="/dashboard/driver">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Set Your Availability</h2>
            <p className="text-gray-600">
              Declare when and where you're available to drive and our AI will match you with passengers.
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-blue-600" />
                Availability Details
              </CardTitle>
              <CardDescription>Set your route, timing, and pricing preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <div className="flex flex-col gap-6">
                  {/* Location Fields */}
                  <div className="grid gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="fromLocation">From (Starting Location)</Label>
                      <Input
                        id="fromLocation"
                        type="text"
                        placeholder="e.g., Downtown LA, 123 Main St"
                        required
                        value={fromLocation}
                        onChange={(e) => setFromLocation(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="toLocation">To (Destination)</Label>
                      <Input
                        id="toLocation"
                        type="text"
                        placeholder="e.g., Inglewood, LAX Airport"
                        required
                        value={toLocation}
                        onChange={(e) => setToLocation(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Route Flexibility */}
                  <div className="grid gap-2">
                    <Label htmlFor="routeFlexibility">Route Flexibility</Label>
                    <Select value={routeFlexibility} onValueChange={setRouteFlexibility}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="exact">Exact Route - No detours</SelectItem>
                        <SelectItem value="flexible">Flexible - Minor detours okay</SelectItem>
                        <SelectItem value="very_flexible">Very Flexible - Open to route changes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Time Fields */}
                  <div className="grid gap-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="availableFromDate">Available From - Date</Label>
                        <Input
                          id="availableFromDate"
                          type="date"
                          required
                          min={new Date().toISOString().split("T")[0]}
                          value={availableFromDate}
                          onChange={(e) => setAvailableFromDate(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="availableFromTime">Available From - Time</Label>
                        <Input
                          id="availableFromTime"
                          type="time"
                          required
                          value={availableFromTime}
                          onChange={(e) => setAvailableFromTime(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="availableUntilDate">Available Until - Date</Label>
                        <Input
                          id="availableUntilDate"
                          type="date"
                          required
                          min={availableFromDate || new Date().toISOString().split("T")[0]}
                          value={availableUntilDate}
                          onChange={(e) => setAvailableUntilDate(e.target.value)}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="availableUntilTime">Available Until - Time</Label>
                        <Input
                          id="availableUntilTime"
                          type="time"
                          required
                          value={availableUntilTime}
                          onChange={(e) => setAvailableUntilTime(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Pricing and Capacity */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="minPrice" className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Minimum Price
                      </Label>
                      <Input
                        id="minPrice"
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="150.00"
                        required
                        value={minPrice}
                        onChange={(e) => setMinPrice(e.target.value)}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="maxPrice">Maximum Price</Label>
                      <Input
                        id="maxPrice"
                        type="number"
                        min="1"
                        step="0.01"
                        placeholder="300.00"
                        required
                        value={maxPrice}
                        onChange={(e) => setMaxPrice(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="availableSeats" className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Available Seats
                    </Label>
                    <Input
                      id="availableSeats"
                      type="number"
                      min="1"
                      max={driverProfile.vehicle_capacity}
                      required
                      value={availableSeats}
                      onChange={(e) => setAvailableSeats(e.target.value)}
                    />
                    <p className="text-sm text-gray-500">
                      Maximum capacity: {driverProfile.vehicle_capacity} passengers
                    </p>
                  </div>

                  {error && <p className="text-sm text-red-500">{error}</p>}

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Setting Availability..." : "Set Availability"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* How It Works */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-green-600" />
                What Happens Next?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">1</span>
                  </div>
                  <p className="text-sm">Our AI solver analyzes your availability and matches with passenger intents</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">2</span>
                  </div>
                  <p className="text-sm">You'll receive notifications when passengers match your route and timing</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-medium text-blue-600">3</span>
                  </div>
                  <p className="text-sm">Accept matches that work for you and start earning money</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
