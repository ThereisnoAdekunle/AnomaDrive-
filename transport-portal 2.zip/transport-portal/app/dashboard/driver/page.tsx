import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import DriverDashboard from "@/components/driver-dashboard"

export default async function DriverDashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and driver profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/onboarding")
  }

  if (profile.user_type !== "driver") {
    redirect("/dashboard/passenger")
  }

  // Get driver profile
  const { data: driverProfile } = await supabase.from("driver_profiles").select("*").eq("id", user.id).single()

  if (!driverProfile) {
    redirect("/onboarding")
  }

  return <DriverDashboard user={user} profile={profile} driverProfile={driverProfile} />
}
