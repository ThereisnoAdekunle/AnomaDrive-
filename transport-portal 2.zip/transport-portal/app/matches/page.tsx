import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import MatchesView from "@/components/matches-view"

export default async function MatchesPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/onboarding")
  }

  // Get user's active intents or availabilities
  let userIntents = []
  let userAvailabilities = []

  if (profile.user_type === "passenger") {
    const { data } = await supabase
      .from("passenger_intents")
      .select("*")
      .eq("passenger_id", user.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
    userIntents = data || []
  } else {
    const { data } = await supabase
      .from("driver_availability")
      .select("*")
      .eq("driver_id", user.id)
      .eq("status", "active")
      .order("created_at", { ascending: false })
    userAvailabilities = data || []
  }

  // Get existing matches
  const { data: matches } = await supabase
    .from("intent_matches")
    .select(`
      *,
      passenger_intents!inner(*),
      driver_availability!inner(*)
    `)
    .or(`passenger_intents.passenger_id.eq.${user.id},driver_availability.driver_id.eq.${user.id}`)
    .order("created_at", { ascending: false })

  return (
    <MatchesView
      user={user}
      profile={profile}
      userIntents={userIntents}
      userAvailabilities={userAvailabilities}
      existingMatches={matches || []}
    />
  )
}
