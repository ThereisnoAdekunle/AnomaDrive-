import { createClient } from "@/lib/supabase/server"
import { paymentService } from "@/lib/payment-service"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { transaction_id, payment_method_id } = await request.json()

    // Get transaction and verify user is the passenger
    const { data: transaction } = await supabase
      .from("transactions")
      .select("*")
      .eq("id", transaction_id)
      .eq("passenger_id", user.id)
      .single()

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    if (transaction.status !== "pending") {
      return NextResponse.json({ error: "Transaction is not in pending state" }, { status: 400 })
    }

    // Authorize payment (hold funds in escrow)
    const paymentResult = await paymentService.authorizePayment(transaction.payment_intent_id!, payment_method_id)

    if (paymentResult.status === "succeeded") {
      // Update transaction status
      const { data: updatedTransaction, error } = await supabase
        .from("transactions")
        .update({
          status: "authorized",
          payment_method_id,
          external_payment_id: paymentResult.id,
          authorized_at: new Date().toISOString(),
        })
        .eq("id", transaction_id)
        .select()
        .single()

      if (error) {
        throw error
      }

      // Create ride session
      await supabase.from("ride_sessions").insert({
        match_id: transaction.match_id,
        transaction_id: transaction.id,
        status: "confirmed",
      })

      return NextResponse.json({
        transaction: updatedTransaction,
        payment_result: paymentResult,
      })
    } else {
      // Update transaction as failed
      await supabase
        .from("transactions")
        .update({
          status: "failed",
          failed_reason: "Payment authorization failed",
        })
        .eq("id", transaction_id)

      return NextResponse.json({ error: "Payment authorization failed" }, { status: 400 })
    }
  } catch (error) {
    console.error("Error authorizing payment:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
