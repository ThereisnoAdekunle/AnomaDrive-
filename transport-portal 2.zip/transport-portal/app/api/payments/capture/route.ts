import { createClient } from "@/lib/supabase/server"
import { paymentService } from "@/lib/payment-service"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { ride_session_id } = await request.json()

    // Get ride session and verify completion
    const { data: rideSession } = await supabase
      .from("ride_sessions")
      .select(`
        *,
        transactions!inner(*)
      `)
      .eq("id", ride_session_id)
      .single()

    if (!rideSession) {
      return NextResponse.json({ error: "Ride session not found" }, { status: 404 })
    }

    // Verify both passenger and driver confirmed completion
    if (!rideSession.passenger_confirmed_dropoff || !rideSession.driver_confirmed_dropoff) {
      return NextResponse.json({ error: "Ride completion not confirmed by both parties" }, { status: 400 })
    }

    const transaction = rideSession.transactions

    // Verify user is involved in this transaction
    if (user.id !== transaction.passenger_id && user.id !== transaction.driver_id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    if (transaction.status !== "authorized") {
      return NextResponse.json({ error: "Payment is not in authorized state" }, { status: 400 })
    }

    // Capture payment (release funds to driver)
    const paymentResult = await paymentService.capturePayment(transaction.payment_intent_id!)

    if (paymentResult.status === "succeeded") {
      // Update transaction status
      const { data: updatedTransaction, error } = await supabase
        .from("transactions")
        .update({
          status: "captured",
          captured_at: new Date().toISOString(),
        })
        .eq("id", transaction.id)
        .select()
        .single()

      if (error) {
        throw error
      }

      // Update ride session status
      await supabase.from("ride_sessions").update({ status: "completed" }).eq("id", ride_session_id)

      // Update match status
      await supabase.from("intent_matches").update({ status: "completed" }).eq("id", rideSession.match_id)

      return NextResponse.json({
        transaction: updatedTransaction,
        message: "Payment captured successfully",
      })
    } else {
      return NextResponse.json({ error: "Payment capture failed" }, { status: 400 })
    }
  } catch (error) {
    console.error("Error capturing payment:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
