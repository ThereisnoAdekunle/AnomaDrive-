import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { match_id, action } = await request.json()

    if (!["accept", "reject"].includes(action)) {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Get the match and verify user permissions
    const { data: match } = await supabase
      .from("intent_matches")
      .select(`
        *,
        passenger_intents!inner(passenger_id),
        driver_availability!inner(driver_id)
      `)
      .eq("id", match_id)
      .single()

    if (!match) {
      return NextResponse.json({ error: "Match not found" }, { status: 404 })
    }

    // Check if user is involved in this match
    const isPassenger = user.id === match.passenger_intents.passenger_id
    const isDriver = user.id === match.driver_availability.driver_id

    if (!isPassenger && !isDriver) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Update match status
    const newStatus = action === "accept" ? "accepted" : "rejected"

    const { data: updatedMatch, error } = await supabase
      .from("intent_matches")
      .update({ status: newStatus })
      .eq("id", match_id)
      .select()
      .single()

    if (error) {
      throw error
    }

    // If accepted, update the intent and availability status to matched
    if (action === "accept") {
      await supabase.from("passenger_intents").update({ status: "matched" }).eq("id", match.passenger_intent_id)

      await supabase.from("driver_availability").update({ status: "matched" }).eq("id", match.driver_availability_id)
    }

    return NextResponse.json({ match: updatedMatch })
  } catch (error) {
    console.error("Error responding to match:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
