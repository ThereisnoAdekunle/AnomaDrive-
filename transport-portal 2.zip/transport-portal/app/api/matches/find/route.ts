import { createClient } from "@/lib/supabase/server"
import { findMatchesForIntent, findMatchesForAvailability } from "@/lib/matching-algorithm"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // Check authentication
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { type, id } = await request.json()

    if (type === "passenger_intent") {
      // Find matches for a passenger intent
      const { data: intent } = await supabase
        .from("passenger_intents")
        .select("*")
        .eq("id", id)
        .eq("passenger_id", user.id)
        .single()

      if (!intent) {
        return NextResponse.json({ error: "Intent not found" }, { status: 404 })
      }

      // Get all active driver availabilities
      const { data: availabilities } = await supabase
        .from("driver_availability")
        .select("*")
        .eq("status", "active")
        .neq("driver_id", user.id)

      const matches = findMatchesForIntent(intent, availabilities || [])

      // Get driver profiles for the matches
      const driverIds = matches
        .map((m) => availabilities?.find((a) => a.id === m.driver_availability_id)?.driver_id)
        .filter(Boolean)

      const { data: driverProfiles } = await supabase.from("profiles").select("id, full_name").in("id", driverIds)

      const { data: driverVehicles } = await supabase
        .from("driver_profiles")
        .select("id, vehicle_make, vehicle_model, vehicle_year, vehicle_color, vehicle_plate")
        .in("id", driverIds)

      // Enrich matches with driver information
      const enrichedMatches = matches.map((match) => {
        const availability = availabilities?.find((a) => a.id === match.driver_availability_id)
        const driverProfile = driverProfiles?.find((p) => p.id === availability?.driver_id)
        const driverVehicle = driverVehicles?.find((v) => v.id === availability?.driver_id)

        return {
          ...match,
          driver: driverProfile,
          vehicle: driverVehicle,
          availability,
        }
      })

      return NextResponse.json({ matches: enrichedMatches })
    } else if (type === "driver_availability") {
      // Find matches for a driver availability
      const { data: availability } = await supabase
        .from("driver_availability")
        .select("*")
        .eq("id", id)
        .eq("driver_id", user.id)
        .single()

      if (!availability) {
        return NextResponse.json({ error: "Availability not found" }, { status: 404 })
      }

      // Get all active passenger intents
      const { data: intents } = await supabase
        .from("passenger_intents")
        .select("*")
        .eq("status", "active")
        .neq("passenger_id", user.id)

      const matches = findMatchesForAvailability(availability, intents || [])

      // Get passenger profiles for the matches
      const passengerIds = matches
        .map((m) => intents?.find((i) => i.id === m.passenger_intent_id)?.passenger_id)
        .filter(Boolean)

      const { data: passengerProfiles } = await supabase.from("profiles").select("id, full_name").in("id", passengerIds)

      // Enrich matches with passenger information
      const enrichedMatches = matches.map((match) => {
        const intent = intents?.find((i) => i.id === match.passenger_intent_id)
        const passengerProfile = passengerProfiles?.find((p) => p.id === intent?.passenger_id)

        return {
          ...match,
          passenger: passengerProfile,
          intent,
        }
      })

      return NextResponse.json({ matches: enrichedMatches })
    }

    return NextResponse.json({ error: "Invalid type" }, { status: 400 })
  } catch (error) {
    console.error("Error finding matches:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
