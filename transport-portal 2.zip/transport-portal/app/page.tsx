import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Car, MapPin, Users, Shield } from "lucide-react"

export default async function HomePage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (user) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">TransportIntent</h1>
          </div>
          <div className="flex gap-3">
            <Button variant="ghost" asChild>
              <Link href="/auth/login">Login</Link>
            </Button>
            <Button asChild>
              <Link href="/auth/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl font-bold text-gray-900 mb-6 text-balance">Declare Your Intent, Find Your Ride</h2>
          <p className="text-xl text-gray-600 mb-8 text-pretty">
            Revolutionary transport matching where passengers declare travel intentions and our AI solver connects them
            with perfect driver matches based on location, timing, and budget preferences.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/auth/signup?type=passenger">Find a Ride</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/auth/signup?type=driver">Become a Driver</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardHeader>
              <MapPin className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>Intent-Based Matching</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Declare where you want to go, when, and your budget. Our solver finds the perfect match automatically.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <CardTitle>Smart Solver Agent</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Advanced AI matches passenger intents with driver availability, optimizing for location, time, and price
                preferences.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Shield className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>Verified & Secure</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                All drivers undergo verification. Secure payments, ratings system, and full journey tracking for safety.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; 2024 TransportIntent. Revolutionizing ride-sharing through intelligent matching.</p>
        </div>
      </footer>
    </div>
  )
}
