// Payment service for handling transactions and escrow functionality

interface PaymentMethod {
  id: string
  user_id: string
  type: string
  provider: string
  external_id: string
  last_four?: string
  brand?: string
  is_default: boolean
  is_active: boolean
}

interface Transaction {
  id: string
  match_id: string
  passenger_id: string
  driver_id: string
  amount: number
  currency: string
  platform_fee: number
  driver_earnings: number
  payment_method_id?: string
  external_payment_id?: string
  status: string
  payment_intent_id?: string
}

interface PaymentIntent {
  id: string
  amount: number
  currency: string
  status: string
  client_secret?: string
}

// Mock payment provider (in real implementation, this would integrate with Stripe, PayPal, etc.)
class MockPaymentProvider {
  async createPaymentIntent(amount: number, currency = "USD"): Promise<PaymentIntent> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const id = `pi_${Math.random().toString(36).substr(2, 9)}`

    return {
      id,
      amount,
      currency,
      status: "requires_payment_method",
      client_secret: `${id}_secret_${Math.random().toString(36).substr(2, 9)}`,
    }
  }

  async confirmPaymentIntent(paymentIntentId: string, paymentMethodId: string): Promise<PaymentIntent> {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Simulate 95% success rate
    const success = Math.random() > 0.05

    return {
      id: paymentIntentId,
      amount: 0, // Would be retrieved from the payment intent
      currency: "USD",
      status: success ? "succeeded" : "requires_payment_method",
    }
  }

  async capturePaymentIntent(paymentIntentId: string): Promise<PaymentIntent> {
    await new Promise((resolve) => setTimeout(resolve, 500))

    return {
      id: paymentIntentId,
      amount: 0,
      currency: "USD",
      status: "succeeded",
    }
  }

  async refundPayment(paymentIntentId: string, amount?: number): Promise<{ id: string; status: string }> {
    await new Promise((resolve) => setTimeout(resolve, 500))

    return {
      id: `re_${Math.random().toString(36).substr(2, 9)}`,
      status: "succeeded",
    }
  }

  async createPaymentMethod(type: string, details: any): Promise<{ id: string; last_four?: string; brand?: string }> {
    await new Promise((resolve) => setTimeout(resolve, 300))

    return {
      id: `pm_${Math.random().toString(36).substr(2, 9)}`,
      last_four: details.last_four || "4242",
      brand: details.brand || "visa",
    }
  }
}

export class PaymentService {
  private provider: MockPaymentProvider

  constructor() {
    this.provider = new MockPaymentProvider()
  }

  // Calculate platform fee (e.g., 5% of transaction)
  calculatePlatformFee(amount: number): number {
    const feePercentage = 0.05 // 5%
    return Math.round(amount * feePercentage * 100) / 100
  }

  // Calculate driver earnings after platform fee
  calculateDriverEarnings(amount: number): number {
    const platformFee = this.calculatePlatformFee(amount)
    return Math.round((amount - platformFee) * 100) / 100
  }

  // Create payment intent for escrow (authorize but don't capture)
  async createEscrowPayment(amount: number, currency = "USD"): Promise<PaymentIntent> {
    return await this.provider.createPaymentIntent(amount, currency)
  }

  // Authorize payment (hold funds in escrow)
  async authorizePayment(paymentIntentId: string, paymentMethodId: string): Promise<PaymentIntent> {
    return await this.provider.confirmPaymentIntent(paymentIntentId, paymentMethodId)
  }

  // Capture payment (release funds from escrow to driver)
  async capturePayment(paymentIntentId: string): Promise<PaymentIntent> {
    return await this.provider.capturePaymentIntent(paymentIntentId)
  }

  // Refund payment (return funds to passenger)
  async refundPayment(paymentIntentId: string, amount?: number): Promise<{ id: string; status: string }> {
    return await this.provider.refundPayment(paymentIntentId, amount)
  }

  // Add payment method for user
  async addPaymentMethod(type: string, details: any): Promise<{ id: string; last_four?: string; brand?: string }> {
    return await this.provider.createPaymentMethod(type, details)
  }

  // Validate payment amount and details
  validatePaymentDetails(amount: number, currency = "USD"): { valid: boolean; errors: string[] } {
    const errors: string[] = []

    if (amount <= 0) {
      errors.push("Amount must be greater than 0")
    }

    if (amount > 10000) {
      errors.push("Amount cannot exceed $10,000")
    }

    if (!["USD", "EUR", "GBP"].includes(currency)) {
      errors.push("Unsupported currency")
    }

    return {
      valid: errors.length === 0,
      errors,
    }
  }

  // Get payment status description
  getPaymentStatusDescription(status: string): string {
    switch (status) {
      case "pending":
        return "Payment is being processed"
      case "authorized":
        return "Payment authorized, funds held in escrow"
      case "captured":
        return "Payment completed successfully"
      case "failed":
        return "Payment failed"
      case "refunded":
        return "Payment has been refunded"
      case "disputed":
        return "Payment is under dispute"
      default:
        return "Unknown payment status"
    }
  }
}

export const paymentService = new PaymentService()
