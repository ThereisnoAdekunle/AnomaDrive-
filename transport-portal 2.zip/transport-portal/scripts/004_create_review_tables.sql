-- Create reviews table for passenger feedback on drivers
CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_session_id UUID NOT NULL REFERENCES public.ride_sessions(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reviewee_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reviewer_type TEXT NOT NULL CHECK (reviewer_type IN ('passenger', 'driver')),
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  comment TEXT,
  categories JSONB, -- For specific rating categories like punctuality, cleanliness, etc.
  is_anonymous BOOLEAN DEFAULT FALSE,
  is_flagged BOOLEAN DEFAULT FALSE,
  flagged_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create review_categories table for structured feedback
CREATE TABLE IF NOT EXISTS public.review_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id UUID NOT NULL REFERENCES public.reviews(id) ON DELETE CASCADE,
  category_name TEXT NOT NULL, -- e.g., 'punctuality', 'cleanliness', 'communication', 'safety'
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create review_responses table for drivers to respond to reviews
CREATE TABLE IF NOT EXISTS public.review_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id UUID NOT NULL REFERENCES public.reviews(id) ON DELETE CASCADE,
  responder_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  response_text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create driver_ratings_summary table for aggregated ratings
CREATE TABLE IF NOT EXISTS public.driver_ratings_summary (
  driver_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  total_reviews INTEGER DEFAULT 0,
  average_rating DECIMAL(3, 2) DEFAULT 0.00,
  five_star_count INTEGER DEFAULT 0,
  four_star_count INTEGER DEFAULT 0,
  three_star_count INTEGER DEFAULT 0,
  two_star_count INTEGER DEFAULT 0,
  one_star_count INTEGER DEFAULT 0,
  category_ratings JSONB, -- Average ratings for each category
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.review_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.review_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_ratings_summary ENABLE ROW LEVEL SECURITY;

-- Create policies for reviews
CREATE POLICY "reviews_select_involved" ON public.reviews 
  FOR SELECT USING (auth.uid() = reviewer_id OR auth.uid() = reviewee_id);

CREATE POLICY "reviews_insert_own" ON public.reviews 
  FOR INSERT WITH CHECK (auth.uid() = reviewer_id);

CREATE POLICY "reviews_update_own" ON public.reviews 
  FOR UPDATE USING (auth.uid() = reviewer_id);

-- Create policies for review_categories
CREATE POLICY "review_categories_select_involved" ON public.review_categories 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.reviews r 
      WHERE r.id = review_id AND (r.reviewer_id = auth.uid() OR r.reviewee_id = auth.uid())
    )
  );

CREATE POLICY "review_categories_insert_own" ON public.review_categories 
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.reviews r 
      WHERE r.id = review_id AND r.reviewer_id = auth.uid()
    )
  );

-- Create policies for review_responses
CREATE POLICY "review_responses_select_involved" ON public.review_responses 
  FOR SELECT USING (
    auth.uid() = responder_id OR 
    EXISTS (
      SELECT 1 FROM public.reviews r 
      WHERE r.id = review_id AND r.reviewer_id = auth.uid()
    )
  );

CREATE POLICY "review_responses_insert_own" ON public.review_responses 
  FOR INSERT WITH CHECK (auth.uid() = responder_id);

CREATE POLICY "review_responses_update_own" ON public.review_responses 
  FOR UPDATE USING (auth.uid() = responder_id);

-- Create policies for driver_ratings_summary (public read, system updates)
CREATE POLICY "driver_ratings_summary_select_all" ON public.driver_ratings_summary 
  FOR SELECT USING (true);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_reviews_ride_session_id ON public.reviews(ride_session_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewer_id ON public.reviews(reviewer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_reviewee_id ON public.reviews(reviewee_id);
CREATE INDEX IF NOT EXISTS idx_reviews_rating ON public.reviews(rating);
CREATE INDEX IF NOT EXISTS idx_review_categories_review_id ON public.review_categories(review_id);
CREATE INDEX IF NOT EXISTS idx_review_responses_review_id ON public.review_responses(review_id);
CREATE INDEX IF NOT EXISTS idx_driver_ratings_summary_average_rating ON public.driver_ratings_summary(average_rating);

-- Create function to update driver ratings summary
CREATE OR REPLACE FUNCTION update_driver_ratings_summary()
RETURNS TRIGGER AS $$
BEGIN
  -- Update or insert driver ratings summary
  INSERT INTO public.driver_ratings_summary (
    driver_id,
    total_reviews,
    average_rating,
    five_star_count,
    four_star_count,
    three_star_count,
    two_star_count,
    one_star_count,
    last_updated
  )
  SELECT 
    reviewee_id,
    COUNT(*) as total_reviews,
    ROUND(AVG(rating::DECIMAL), 2) as average_rating,
    COUNT(*) FILTER (WHERE rating = 5) as five_star_count,
    COUNT(*) FILTER (WHERE rating = 4) as four_star_count,
    COUNT(*) FILTER (WHERE rating = 3) as three_star_count,
    COUNT(*) FILTER (WHERE rating = 2) as two_star_count,
    COUNT(*) FILTER (WHERE rating = 1) as one_star_count,
    NOW()
  FROM public.reviews 
  WHERE reviewee_id = COALESCE(NEW.reviewee_id, OLD.reviewee_id)
    AND reviewer_type = 'passenger'
  GROUP BY reviewee_id
  ON CONFLICT (driver_id) 
  DO UPDATE SET
    total_reviews = EXCLUDED.total_reviews,
    average_rating = EXCLUDED.average_rating,
    five_star_count = EXCLUDED.five_star_count,
    four_star_count = EXCLUDED.four_star_count,
    three_star_count = EXCLUDED.three_star_count,
    two_star_count = EXCLUDED.two_star_count,
    one_star_count = EXCLUDED.one_star_count,
    last_updated = EXCLUDED.last_updated;

  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update driver ratings summary
CREATE TRIGGER trigger_update_driver_ratings_summary
  AFTER INSERT OR UPDATE OR DELETE ON public.reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_driver_ratings_summary();

-- Insert some default category definitions (optional)
INSERT INTO public.review_categories (review_id, category_name, rating)
VALUES 
  ('00000000-0000-0000-0000-000000000000', 'punctuality', 5),
  ('00000000-0000-0000-0000-000000000000', 'cleanliness', 5),
  ('00000000-0000-0000-0000-000000000000', 'communication', 5),
  ('00000000-0000-0000-0000-000000000000', 'safety', 5),
  ('00000000-0000-0000-0000-000000000000', 'vehicle_condition', 5)
ON CONFLICT DO NOTHING;
